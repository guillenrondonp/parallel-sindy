"""
sindy_core.py
=============
Core SINDy machinery (Brunton, Proctor & Kutz, PNAS 2016, arXiv:1509.03580)
written as plain loops so that the SAME source can be compiled by

  * numba.njit                 (serial, or nogil for Python threads)
  * numba.njit(parallel=True)  (prange drivers live in backends.py)
  * numba.openmp.njit          (PyOMP: real OpenMP pragmas)

The kernels are created by a factory, ``build_kernels(jit)``, which receives the
decorator to use.  Every backend therefore runs bit-for-bit the same algorithm,
so timing differences come only from the parallelisation strategy.

Pipeline for one trajectory (paper, Sec. "Methods"):

    x0 --RK4--> X(t) --central differences--> dX/dt
                 |
                 +--polynomial library--> Theta(X)
    Theta, dX/dt --STLSQ (sequentially thresholded least squares)--> Xi

Systems:
    Lorenz : x' = s(y-x),      y' = x(r-z) - y,   z' = xy - b z
    Rossler: x' = -y - z,      y' = x + a y,       z' = b + z(x - c)
"""
from itertools import combinations_with_replacement

import numpy as np

# ----------------------------------------------------------------------------
# System definitions (pure Python metadata)
# ----------------------------------------------------------------------------
LORENZ, ROSSLER = 0, 1
SYSTEMS = {"lorenz": LORENZ, "rossler": ROSSLER}

DEFAULT_PARAMS = {
    "lorenz": np.array([10.0, 28.0, 8.0 / 3.0]),   # sigma, rho, beta
    "rossler": np.array([0.2, 0.2, 5.7]),         # a, b, c
}
DEFAULT_DT = {"lorenz": 0.002, "rossler": 0.005}
DEFAULT_THRESHOLD = {"lorenz": 0.1, "rossler": 0.05}


def exponent_table(n_vars: int, degree: int) -> np.ndarray:
    """Monomial exponents in the same order as pysindy.PolynomialLibrary:
    1, x, y, z, x^2, xy, xz, y^2, yz, z^2, x^3, ..."""
    rows = []
    for d in range(degree + 1):
        for combo in combinations_with_replacement(range(n_vars), d):
            e = [0] * n_vars
            for k in combo:
                e[k] += 1
            rows.append(e)
    return np.array(rows, dtype=np.int64)


def term_names(expo: np.ndarray, var_names=("x", "y", "z")) -> list:
    names = []
    for e in expo:
        parts = []
        for v, p in zip(var_names, e):
            if p == 1:
                parts.append(v)
            elif p > 1:
                parts.append(f"{v}^{p}")
        names.append(" ".join(parts) if parts else "1")
    return names


def true_coefficients(system: str, expo: np.ndarray) -> np.ndarray:
    """Ground-truth Xi (n_terms x 3) for the chosen system."""
    names = term_names(expo)
    idx = {n: i for i, n in enumerate(names)}
    xi = np.zeros((len(names), 3))
    p = DEFAULT_PARAMS[system]
    if system == "lorenz":
        s, r, b = p
        xi[idx["x"], 0], xi[idx["y"], 0] = -s, s
        xi[idx["x"], 1], xi[idx["y"], 1], xi[idx["x z"], 1] = r, -1.0, -1.0
        xi[idx["x y"], 2], xi[idx["z"], 2] = 1.0, -b
    else:
        a, b, c = p
        xi[idx["y"], 0], xi[idx["z"], 0] = -1.0, -1.0
        xi[idx["x"], 1], xi[idx["y"], 1] = 1.0, a
        xi[idx["1"], 2], xi[idx["z"], 2], xi[idx["x z"], 2] = b, -c, 1.0
    return xi


def format_equations(xi: np.ndarray, expo: np.ndarray, precision=3) -> str:
    names = term_names(expo)
    lines = []
    for j, lhs in enumerate(("x'", "y'", "z'")):
        terms = [f"{xi[i, j]:+.{precision}f} {n}".replace(" 1", "")
                 for i, n in enumerate(names) if xi[i, j] != 0.0]
        lines.append(f"{lhs} = " + (" ".join(terms) if terms else "0"))
    return "\n".join(lines)


def initial_conditions(system: str, m: int, seed: int = 0) -> np.ndarray:
    """m random initial conditions near the attractor."""
    rng = np.random.default_rng(seed)
    if system == "lorenz":
        lo, hi = np.array([-15.0, -20.0, 5.0]), np.array([15.0, 20.0, 40.0])
    else:
        lo, hi = np.array([-8.0, -8.0, 0.0]), np.array([8.0, 8.0, 2.0])
    return lo + (hi - lo) * rng.random((m, 3))


# ----------------------------------------------------------------------------
# Kernel factory
# ----------------------------------------------------------------------------
def build_kernels(jit):
    """Compile the SINDy kernels with decorator ``jit`` and return them in a
    dict.  ``jit`` is e.g. ``numba.njit(cache=True, nogil=True)`` or PyOMP's
    ``numba.openmp.njit``."""

    @jit
    def rhs(system, p, x, y, z, out):
        if system == 0:          # Lorenz
            out[0] = p[0] * (y - x)
            out[1] = x * (p[1] - z) - y
            out[2] = x * y - p[2] * z
        else:                    # Rossler
            out[0] = -y - z
            out[1] = x + p[0] * y
            out[2] = p[1] + z * (x - p[2])

    @jit
    def integrate_rk4(system, p, x0, dt, n):
        """Classic 4th-order Runge-Kutta, n samples (including x0)."""
        X = np.empty((n, 3))
        k1 = np.empty(3); k2 = np.empty(3); k3 = np.empty(3); k4 = np.empty(3)
        X[0, 0], X[0, 1], X[0, 2] = x0[0], x0[1], x0[2]
        h2 = 0.5 * dt
        for i in range(n - 1):
            a, b, c = X[i, 0], X[i, 1], X[i, 2]
            rhs(system, p, a, b, c, k1)
            rhs(system, p, a + h2 * k1[0], b + h2 * k1[1], c + h2 * k1[2], k2)
            rhs(system, p, a + h2 * k2[0], b + h2 * k2[1], c + h2 * k2[2], k3)
            rhs(system, p, a + dt * k3[0], b + dt * k3[1], c + dt * k3[2], k4)
            for k in range(3):
                X[i + 1, k] = X[i, k] + dt / 6.0 * (k1[k] + 2.0 * k2[k] + 2.0 * k3[k] + k4[k])
        return X

    @jit
    def central_diff(X, dt):
        """2nd-order finite differences (one-sided at the ends), like
        pysindy.FiniteDifference(order=2)."""
        n, d = X.shape
        D = np.empty((n, d))
        inv2 = 1.0 / (2.0 * dt)
        for k in range(d):
            D[0, k] = (-3.0 * X[0, k] + 4.0 * X[1, k] - X[2, k]) * inv2
            D[n - 1, k] = (3.0 * X[n - 1, k] - 4.0 * X[n - 2, k] + X[n - 3, k]) * inv2
            for i in range(1, n - 1):
                D[i, k] = (X[i + 1, k] - X[i - 1, k]) * inv2
        return D

    @jit
    def library_row(X, i, expo, theta, row):
        """Theta[row, :] = monomials of X[i, :]."""
        m, d = expo.shape
        for j in range(m):
            v = 1.0
            for k in range(d):
                for _ in range(expo[j, k]):
                    v *= X[i, k]
            theta[row, j] = v

    @jit
    def library_serial(X, expo):
        n = X.shape[0]
        theta = np.empty((n, expo.shape[0]))
        for i in range(n):
            library_row(X, i, expo, theta, i)
        return theta

    @jit
    def accumulate_normal_eq(theta, dX, i0, i1, G, R):
        """G += Theta[i0:i1]^T Theta[i0:i1],  R += Theta[i0:i1]^T dX[i0:i1].
        Writing the products as loops keeps every backend free of BLAS
        (and of BLAS's own threads, which would distort the core count)."""
        m = theta.shape[1]
        d = dX.shape[1]
        for i in range(i0, i1):
            for a in range(m):
                ta = theta[i, a]
                for b in range(a, m):
                    G[a, b] += ta * theta[i, b]
                for k in range(d):
                    R[a, k] += ta * dX[i, k]

    @jit
    def symmetrize(G):
        m = G.shape[0]
        for a in range(m):
            for b in range(a):
                G[a, b] = G[b, a]

    @jit
    def solve_spd(A, b):
        """Gaussian elimination with partial pivoting (small dense systems)."""
        n = A.shape[0]
        M = A.copy()
        x = b.copy()
        for c in range(n):
            piv = c
            for r in range(c + 1, n):
                if abs(M[r, c]) > abs(M[piv, c]):
                    piv = r
            if piv != c:
                for k in range(n):
                    M[c, k], M[piv, k] = M[piv, k], M[c, k]
                x[c], x[piv] = x[piv], x[c]
            for r in range(c + 1, n):
                f = M[r, c] / M[c, c]
                for k in range(c, n):
                    M[r, k] -= f * M[c, k]
                x[r] -= f * x[c]
        for r in range(n - 1, -1, -1):
            s = x[r]
            for k in range(r + 1, n):
                s -= M[r, k] * x[k]
            x[r] = s / M[r, r]
        return x

    @jit
    def stlsq_from_normal_eq(G, R, threshold, ridge, max_iter):
        """Sequentially thresholded least squares (Algorithm in the PNAS
        paper) working on the normal equations G = Theta^T Theta,
        R = Theta^T dX.  Columns are rescaled to unit norm for conditioning;
        the threshold is applied to the coefficients in original units."""
        m, d = R.shape
        scale = np.empty(m)
        for a in range(m):
            scale[a] = 1.0 / np.sqrt(G[a, a]) if G[a, a] > 0 else 1.0
        Gs = np.empty((m, m))
        for a in range(m):
            for b in range(m):
                Gs[a, b] = G[a, b] * scale[a] * scale[b]
        Xi = np.zeros((m, d))
        for k in range(d):
            active = np.ones(m, dtype=np.bool_)
            for it in range(max_iter):
                idx = np.nonzero(active)[0]
                na = idx.shape[0]
                if na == 0:
                    break
                A = np.empty((na, na))
                rhs_ = np.empty(na)
                for p in range(na):
                    rhs_[p] = R[idx[p], k] * scale[idx[p]]
                    for q in range(na):
                        A[p, q] = Gs[idx[p], idx[q]]
                    A[p, p] += ridge * scale[idx[p]] * scale[idx[p]]   # ridge on UNscaled columns (PySINDy convention)
                c = solve_spd(A, rhs_)
                for a in range(m):
                    Xi[a, k] = 0.0
                for p in range(na):
                    Xi[idx[p], k] = c[p] * scale[idx[p]]
                changed = False
                for a in range(m):
                    keep = abs(Xi[a, k]) >= threshold
                    if keep != active[a]:
                        changed = True
                    active[a] = keep
                    if not keep:
                        Xi[a, k] = 0.0
                if not changed:
                    break
            # final refit on the surviving support is the last iterate
        return Xi

    # ------------------------------------------------------------------
    # Numerical safeguard. Forming G = Theta^T Theta squares the condition
    # number of Theta. When the column-scaled G has cond > COND_MAX, the
    # normal-equation solve is unreliable (e.g. a trajectory that stays
    # near an unstable equilibrium), and we switch to a QR (TSQR)
    # reduction of [Theta | dX], which works with cond(Theta) itself.
    # ------------------------------------------------------------------
    @jit
    def gram_condition(G):
        m = G.shape[0]
        Gs = np.empty((m, m))
        for a in range(m):
            for b in range(m):
                Gs[a, b] = G[a, b] / np.sqrt(G[a, a] * G[b, b])
        ev = np.linalg.eigvalsh(Gs)
        lo = ev[0] if ev[0] > 1e-300 else 1e-300
        return ev[m - 1] / lo

    @jit
    def qr_reduce(X, dX, expo, i0, i1, block):
        """Upper-triangular Rq ((m+3)x(m+3)) with [Theta|dX] = Q Rq for rows
        [i0, i1), built block by block (blocked TSQR, O(block*m) memory)."""
        m = expo.shape[0]
        d = dX.shape[1]
        k = m + d
        Rq = np.zeros((k, k))
        b0 = i0
        while b0 < i1:
            b1 = min(i1, b0 + block)
            nb = b1 - b0
            A = np.zeros((k + nb, k))
            A[:k, :] = Rq
            buf = np.empty((nb, m))
            for i in range(b0, b1):
                library_row(X, i, expo, buf, i - b0)
            for r in range(nb):
                for j in range(m):
                    A[k + r, j] = buf[r, j]
                for j in range(d):
                    A[k + r, m + j] = dX[b0 + r, j]
            _, rr = np.linalg.qr(A)
            Rq = np.ascontiguousarray(rr[:k, :])
            b0 = b1
        return Rq

    @jit
    def stack_qr(Rs):
        """Combine several R factors (p x k x k) into one: the TSQR reduction."""
        p, k, _ = Rs.shape
        A = np.empty((p * k, k))
        for t in range(p):
            A[t * k:(t + 1) * k, :] = Rs[t]
        _, rr = np.linalg.qr(A)
        return np.ascontiguousarray(rr[:k, :])

    @jit
    def stlsq_from_qr(Rq, m, threshold, ridge, max_iter):
        """STLSQ using the R factor: ||Theta_S xi - dx_k|| = ||Rq[:,S] xi - Rq[:,m+k]||."""
        k_all = Rq.shape[0]
        d = k_all - m
        scale = np.empty(m)
        for a in range(m):
            nrm = 0.0
            for r in range(k_all):
                nrm += Rq[r, a] * Rq[r, a]
            scale[a] = 1.0 / np.sqrt(nrm) if nrm > 0 else 1.0
        Xi = np.zeros((m, d))
        sr = np.sqrt(ridge)
        for k in range(d):
            active = np.ones(m, dtype=np.bool_)
            for it in range(max_iter):
                idx = np.nonzero(active)[0]
                na = idx.shape[0]
                if na == 0:
                    break
                A = np.zeros((k_all + na, na))
                b = np.zeros(k_all + na)
                for r in range(k_all):
                    b[r] = Rq[r, m + k]
                    for q in range(na):
                        A[r, q] = Rq[r, idx[q]] * scale[idx[q]]
                for q in range(na):
                    A[k_all + q, q] = sr * scale[idx[q]]          # ridge on UNscaled columns
                c = np.linalg.lstsq(A, b)[0]
                for a in range(m):
                    Xi[a, k] = 0.0
                for q in range(na):
                    Xi[idx[q], k] = c[q] * scale[idx[q]]
                changed = False
                for a in range(m):
                    keep = abs(Xi[a, k]) >= threshold
                    if keep != active[a]:
                        changed = True
                    active[a] = keep
                    if not keep:
                        Xi[a, k] = 0.0
                if not changed:
                    break
        return Xi

    @jit
    def solve_checked(G, R, X, dX, expo, threshold):
        """Fast normal-equation STLSQ, with automatic QR fallback when the
        scaled Gram matrix is too ill-conditioned (cond > 1e10)."""
        if gram_condition(G) > 1e10:
            Rq = qr_reduce(X, dX, expo, 0, X.shape[0], 4096)
            return stlsq_from_qr(Rq, expo.shape[0], threshold, 1e-10, 25)
        return stlsq_from_normal_eq(G, R, threshold, 1e-10, 25)

    @jit
    def sindy_one(system, p, x0, dt, n, expo, threshold):
        """Complete SINDy for ONE trajectory (serial). Used by every
        task-parallel backend (prange, OpenMP, processes, threads)."""
        X = integrate_rk4(system, p, x0, dt, n)
        dX = central_diff(X, dt)
        theta = library_serial(X, expo)
        m = expo.shape[0]
        G = np.zeros((m, m))
        R = np.zeros((m, 3))
        accumulate_normal_eq(theta, dX, 0, n, G, R)
        symmetrize(G)
        return solve_checked(G, R, X, dX, expo, threshold)

    @jit
    def library_gram_chunk(X, dX, expo, i0, i1, G, R):
        """Data-parallel building block: build Theta for rows [i0, i1) in a
        small buffer and add its contribution to G and R."""
        m = expo.shape[0]
        nb = i1 - i0
        buf = np.empty((nb, m))
        for i in range(i0, i1):
            library_row(X, i, expo, buf, i - i0)
        accumulate_normal_eq(buf, dX[i0:i1], 0, nb, G, R)

    return dict(rhs=rhs, integrate_rk4=integrate_rk4, central_diff=central_diff,
                library_row=library_row, library_serial=library_serial,
                accumulate_normal_eq=accumulate_normal_eq, symmetrize=symmetrize,
                solve_spd=solve_spd, stlsq_from_normal_eq=stlsq_from_normal_eq,
                gram_condition=gram_condition, qr_reduce=qr_reduce, stack_qr=stack_qr,
                stlsq_from_qr=stlsq_from_qr, solve_checked=solve_checked,
                sindy_one=sindy_one, library_gram_chunk=library_gram_chunk)
