"""
run_backend.py
==============
Run ONE (system, workload, backend, cores) case in a fresh interpreter and
print a JSON line with the timings and an accuracy check.  benchmark.py calls
this repeatedly; you can also call it by hand, e.g.

    python run_backend.py --system lorenz --workload ensemble --backend pyomp --cores 4
    python run_backend.py --system rossler --workload library --backend numba --cores 8 --show

A fresh process per case is deliberate: thread-pool sizes are fixed through
environment variables before Numba / OpenMP / BLAS are imported, and Numba's
and PyOMP's thread pools never coexist.
"""
import argparse
import json
import os
import sys
import time


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--system", choices=["lorenz", "rossler"], default="lorenz")
    ap.add_argument("--workload", choices=["ensemble", "library"], default="ensemble")
    ap.add_argument("--backend", default="serial",
                    choices=["serial", "numba", "pyomp", "threads", "processes", "pysindy"])
    ap.add_argument("--cores", type=int, default=1)
    ap.add_argument("--repeats", type=int, default=3)
    ap.add_argument("--M", type=int, default=96, help="ensemble: number of trajectories")
    ap.add_argument("--n", type=int, default=20000, help="ensemble: samples per trajectory")
    ap.add_argument("--N", type=int, default=2_000_000, help="library: samples of the long trajectory")
    ap.add_argument("--ens-degree", type=int, default=3, help="ensemble: polynomial degree")
    ap.add_argument("--lib-degree", type=int, default=5, help="library: polynomial degree (paper uses 5)")
    ap.add_argument("--show", action="store_true", help="print the identified equations")
    args = ap.parse_args()

    p = args.cores
    # ---- fix every thread pool BEFORE numba / numpy are imported ---------------
    os.environ["NUMBA_NUM_THREADS"] = str(p if args.backend == "numba" else 1)
    os.environ["OMP_NUM_THREADS"] = str(p if args.backend == "pyomp" else 1)
    for v in ("OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "VECLIB_MAXIMUM_THREADS"):
        os.environ[v] = "1"     # BLAS stays serial everywhere -> clean core counts

    import numpy as np  # noqa: E402

    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from sindy_core import (SYSTEMS, DEFAULT_PARAMS, DEFAULT_DT, DEFAULT_THRESHOLD,  # noqa: E402
                            exponent_table, true_coefficients, format_equations,
                            initial_conditions)

    system = args.system
    sid = SYSTEMS[system]
    prm = DEFAULT_PARAMS[system]
    dt = DEFAULT_DT[system]
    thr = DEFAULT_THRESHOLD[system]
    degree = args.ens_degree if args.workload == "ensemble" else args.lib_degree
    expo = exponent_table(3, degree)
    truth = true_coefficients(system, expo)


    def timed(fn, repeats):
        fn()                                  # warm-up: JIT compile, start pools
        ts = []
        for _ in range(repeats):
            t0 = time.perf_counter()
            res = fn()
            ts.append(time.perf_counter() - t0)
        return res, ts


    cleanup = []

    # ---------------------------------------------------------------------------
    if args.workload == "ensemble":
        x0s = initial_conditions(system, args.M, seed=1)
        n = args.n

        if args.backend == "pysindy":
            import warnings
            import pysindy as ps
            from backends_numba import K
            integ = K["integrate_rk4"]
            warnings.filterwarnings("ignore")

            def run():
                out = []
                for x0 in x0s:
                    X = integ(sid, prm, x0, dt, n)
                    model = ps.SINDy(optimizer=ps.STLSQ(threshold=thr, alpha=1e-10),
                                     feature_library=ps.PolynomialLibrary(degree=degree),
                                     differentiation_method=ps.FiniteDifference())
                    model.fit(X, t=dt)
                    out.append(model.coefficients().T)
                return np.array(out)
        elif args.backend == "pyomp":
            from backends_pyomp import ensemble_omp
            def run():
                return ensemble_omp(sid, prm, x0s, dt, n, expo, thr)
        else:
            import backends_numba as B
            if args.backend == "serial":
                def run():
                    return B.ensemble_serial(sid, prm, x0s, dt, n, expo, thr)
            elif args.backend == "numba":
                import numba
                numba.set_num_threads(p)
                def run():
                    return B.ensemble_prange(sid, prm, x0s, dt, n, expo, thr)
            elif args.backend == "threads":
                from concurrent.futures import ThreadPoolExecutor
                tp = ThreadPoolExecutor(p); cleanup.append(tp.shutdown)
                def run():
                    return B.ensemble_threads(sid, prm, x0s, dt, n, expo, thr, p, tp)
            elif args.backend == "processes":
                pool = B.mp_context().Pool(p)
                cleanup.append(lambda: (pool.close(), pool.join()))
                def run():
                    return B.ensemble_processes(sid, prm, x0s, dt, n, expo, thr, p, pool)

        Xi_all, times = timed(run, args.repeats)
        err = np.abs(Xi_all - truth[None]).max(axis=(1, 2))
        support_ok = np.all((Xi_all != 0) == (truth[None] != 0), axis=(1, 2))
        Xi_show = np.median(Xi_all, axis=0)
        accuracy = dict(max_coef_error=float(err.max()),
                        median_coef_error=float(np.median(err)),
                        correct_support_fraction=float(support_ok.mean()))
        size = dict(M=args.M, n=n, degree=degree, terms=int(expo.shape[0]))

    # ---------------------------------------------------------------------------
    else:   # library workload: one long trajectory
        if args.backend == "pyomp":
            from backends_pyomp import K as KK
        else:
            from backends_numba import K as KK
        x0 = initial_conditions(system, 1, seed=7)[0]
        X = KK["integrate_rk4"](sid, prm, x0, dt, args.N)
        dX = KK["central_diff"](X, dt)

        if args.backend == "pysindy":
            import warnings
            import pysindy as ps
            warnings.filterwarnings("ignore")

            def run():
                model = ps.SINDy(optimizer=ps.STLSQ(threshold=thr, alpha=1e-10),
                                 feature_library=ps.PolynomialLibrary(degree=degree))
                model.fit(X, t=dt, x_dot=dX)
                return model.coefficients().T
        elif args.backend == "pyomp":
            from backends_pyomp import library_omp_fit
            def run():
                return library_omp_fit(X, dX, expo, thr, p)
        else:
            import backends_numba as B
            if args.backend == "serial":
                def run():
                    return B.library_serial_fit(X, dX, expo, thr)
            elif args.backend == "numba":
                import numba
                numba.set_num_threads(p)
                def run():
                    return B.library_prange_fit(X, dX, expo, thr, p)
            elif args.backend == "threads":
                from concurrent.futures import ThreadPoolExecutor
                tp = ThreadPoolExecutor(p); cleanup.append(tp.shutdown)
                def run():
                    return B.library_threads_fit(X, dX, expo, thr, p, tp)
            elif args.backend == "processes":
                st = B.SharedTrajectory(X, dX, p, B.mp_context())
                cleanup.append(st.close)
                def run():
                    return st.fit(expo, thr, X, dX)

        Xi_show, times = timed(run, args.repeats)
        err = float(np.abs(Xi_show - truth).max())
        accuracy = dict(max_coef_error=err, median_coef_error=err,
                        correct_support_fraction=float(np.all((Xi_show != 0) == (truth != 0))))
        size = dict(N=args.N, degree=degree, terms=int(expo.shape[0]))

    for c in cleanup:
        c()

    if args.show:
        print(f"# {system} / {args.workload} / {args.backend} / {p} cores", file=sys.stderr)
        print(format_equations(Xi_show, expo), file=sys.stderr)

    print(json.dumps(dict(system=system, workload=args.workload, backend=args.backend,
                          cores=p, time_best=min(times), time_median=float(np.median(times)),
                          times=times, **size, **accuracy)))


if __name__ == "__main__":   # required for multiprocessing "spawn" (macOS, Windows)
    main()
