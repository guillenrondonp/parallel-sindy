cat summary.md 
# Parallel SINDy benchmark

Machine: 48 logical CPUs. Times are the best of 3 runs after a JIT/pool warm-up.

S(p) = T(Numba serial) / T(backend, p cores); E(p) = S(p)/p.


## Lorenz - ensemble (M=960 trajectories x n=20000 samples, degree 3)

Numba serial: 9.7568 s
 | PySINDy serial: 42.4132 s (compiled serial is 4.3x faster)


| backend | cores | time [s] | speed-up S | efficiency E | max coef. error |
|---|---:|---:|---:|---:|---:|
| Numba prange | 1 | 9.7457 | 1.00 | 1.00 | 1.8e+02 |
| Numba prange | 2 | 4.8826 | 2.00 | 1.00 | 1.8e+02 |
| Numba prange | 4 | 2.5464 | 3.83 | 0.96 | 1.8e+02 |
| Numba prange | 8 | 1.4014 | 6.96 | 0.87 | 1.8e+02 |
| Numba prange | 12 | 0.9373 | 10.41 | 0.87 | 1.8e+02 |
| Numba prange | 16 | 0.7141 | 13.66 | 0.85 | 1.8e+02 |
| Numba prange | 24 | 0.4889 | 19.96 | 0.83 | 1.8e+02 |
| Numba prange | 48 | 0.4553 | 21.43 | 0.45 | 1.8e+02 |
| PyOMP (OpenMP) | 1 | 10.1381 | 0.96 | 0.96 | 1.8e+02 |
| PyOMP (OpenMP) | 2 | 5.0825 | 1.92 | 0.96 | 1.8e+02 |
| PyOMP (OpenMP) | 4 | 2.6574 | 3.67 | 0.92 | 1.8e+02 |
| PyOMP (OpenMP) | 8 | 1.4573 | 6.70 | 0.84 | 1.8e+02 |
| PyOMP (OpenMP) | 12 | 0.9748 | 10.01 | 0.83 | 1.8e+02 |
| PyOMP (OpenMP) | 16 | 0.7359 | 13.26 | 0.83 | 1.8e+02 |
| PyOMP (OpenMP) | 24 | 0.5087 | 19.18 | 0.80 | 1.8e+02 |
| PyOMP (OpenMP) | 48 | 0.4698 | 20.77 | 0.43 | 1.8e+02 |
| Python threads (nogil) | 1 | 9.7528 | 1.00 | 1.00 | 1.8e+02 |
| Python threads (nogil) | 2 | 4.9241 | 1.98 | 0.99 | 1.8e+02 |
| Python threads (nogil) | 4 | 2.5425 | 3.84 | 0.96 | 1.8e+02 |
| Python threads (nogil) | 8 | 1.4494 | 6.73 | 0.84 | 1.8e+02 |
| Python threads (nogil) | 12 | 0.9818 | 9.94 | 0.83 | 1.8e+02 |
| Python threads (nogil) | 16 | 0.7420 | 13.15 | 0.82 | 1.8e+02 |
| Python threads (nogil) | 24 | 0.5761 | 16.93 | 0.71 | 1.8e+02 |
| Python threads (nogil) | 48 | 0.4804 | 20.31 | 0.42 | 1.8e+02 |
| multiprocessing | 1 | 9.7742 | 1.00 | 1.00 | 1.8e+02 |
| multiprocessing | 2 | 4.9577 | 1.97 | 0.98 | 1.8e+02 |
| multiprocessing | 4 | 2.6704 | 3.65 | 0.91 | 1.8e+02 |
| multiprocessing | 8 | 1.4833 | 6.58 | 0.82 | 1.8e+02 |
| multiprocessing | 12 | 0.9795 | 9.96 | 0.83 | 1.8e+02 |
| multiprocessing | 16 | 0.7399 | 13.19 | 0.82 | 1.8e+02 |
| multiprocessing | 24 | 0.6614 | 14.75 | 0.61 | 1.8e+02 |
| multiprocessing | 48 | 0.4818 | 20.25 | 0.42 | 1.8e+02 |

## Lorenz - library (N=20000000 samples, degree 5 (56 candidate terms))

Numba serial: 49.8049 s
 | PySINDy serial: 235.2881 s (compiled serial is 4.7x faster)


| backend | cores | time [s] | speed-up S | efficiency E | max coef. error |
|---|---:|---:|---:|---:|---:|
| Numba prange | 1 | 49.5603 | 1.00 | 1.00 | 8.0e-03 |
| Numba prange | 2 | 28.4329 | 1.75 | 0.88 | 8.0e-03 |
| Numba prange | 4 | 14.1694 | 3.51 | 0.88 | 8.0e-03 |
| Numba prange | 8 | 8.0174 | 6.21 | 0.78 | 8.0e-03 |
| Numba prange | 12 | 5.6315 | 8.84 | 0.74 | 8.0e-03 |
| Numba prange | 16 | 4.1759 | 11.93 | 0.75 | 8.0e-03 |
| Numba prange | 24 | 2.8222 | 17.65 | 0.74 | 8.0e-03 |
| Numba prange | 48 | 2.5993 | 19.16 | 0.40 | 8.0e-03 |
| PyOMP (OpenMP) | 1 | 50.4415 | 0.99 | 0.99 | 8.0e-03 |
| PyOMP (OpenMP) | 2 | 27.9831 | 1.78 | 0.89 | 8.0e-03 |
| PyOMP (OpenMP) | 4 | 14.6688 | 3.40 | 0.85 | 8.0e-03 |
| PyOMP (OpenMP) | 8 | 8.0475 | 6.19 | 0.77 | 8.0e-03 |
| PyOMP (OpenMP) | 12 | 5.8491 | 8.51 | 0.71 | 8.0e-03 |
| PyOMP (OpenMP) | 16 | 4.3501 | 11.45 | 0.72 | 8.0e-03 |
| PyOMP (OpenMP) | 24 | 3.1092 | 16.02 | 0.67 | 8.0e-03 |
| PyOMP (OpenMP) | 48 | 2.7586 | 18.05 | 0.38 | 8.0e-03 |
| Python threads (nogil) | 1 | 49.5442 | 1.01 | 1.01 | 8.0e-03 |
| Python threads (nogil) | 2 | 24.8451 | 2.00 | 1.00 | 8.0e-03 |
| Python threads (nogil) | 4 | 12.7990 | 3.89 | 0.97 | 8.0e-03 |
| Python threads (nogil) | 8 | 7.1460 | 6.97 | 0.87 | 8.0e-03 |
| Python threads (nogil) | 12 | 4.8347 | 10.30 | 0.86 | 8.0e-03 |
| Python threads (nogil) | 16 | 3.6775 | 13.54 | 0.85 | 8.0e-03 |
| Python threads (nogil) | 24 | 2.4685 | 20.18 | 0.84 | 8.0e-03 |
| Python threads (nogil) | 48 | 2.3774 | 20.95 | 0.44 | 8.0e-03 |
| multiprocessing | 1 | 49.5706 | 1.00 | 1.00 | 8.0e-03 |
| multiprocessing | 2 | 24.8115 | 2.01 | 1.00 | 8.0e-03 |
| multiprocessing | 4 | 12.8360 | 3.88 | 0.97 | 8.0e-03 |
| multiprocessing | 8 | 7.3543 | 6.77 | 0.85 | 8.0e-03 |
| multiprocessing | 12 | 4.8873 | 10.19 | 0.85 | 8.0e-03 |
| multiprocessing | 16 | 3.6847 | 13.52 | 0.84 | 8.0e-03 |
| multiprocessing | 24 | 2.5082 | 19.86 | 0.83 | 8.0e-03 |
| multiprocessing | 48 | 2.3837 | 20.89 | 0.44 | 8.0e-03 |

## Rossler - ensemble (M=960 trajectories x n=20000 samples, degree 3)

Numba serial: 9.7113 s
 | PySINDy serial: 42.4176 s (compiled serial is 4.4x faster)


| backend | cores | time [s] | speed-up S | efficiency E | max coef. error |
|---|---:|---:|---:|---:|---:|
| Numba prange | 1 | 9.7130 | 1.00 | 1.00 | 2.1e-03 |
| Numba prange | 2 | 4.8739 | 1.99 | 1.00 | 2.1e-03 |
| Numba prange | 4 | 2.5100 | 3.87 | 0.97 | 2.1e-03 |
| Numba prange | 8 | 1.3776 | 7.05 | 0.88 | 2.1e-03 |
| Numba prange | 12 | 0.9336 | 10.40 | 0.87 | 2.1e-03 |
| Numba prange | 16 | 0.7112 | 13.66 | 0.85 | 2.1e-03 |
| Numba prange | 24 | 0.4934 | 19.68 | 0.82 | 2.1e-03 |
| Numba prange | 48 | 0.4522 | 21.47 | 0.45 | 2.1e-03 |
| PyOMP (OpenMP) | 1 | 10.1250 | 0.96 | 0.96 | 2.1e-03 |
| PyOMP (OpenMP) | 2 | 5.0780 | 1.91 | 0.96 | 2.1e-03 |
| PyOMP (OpenMP) | 4 | 2.6644 | 3.64 | 0.91 | 2.1e-03 |
| PyOMP (OpenMP) | 8 | 1.4439 | 6.73 | 0.84 | 2.1e-03 |
| PyOMP (OpenMP) | 12 | 0.9756 | 9.95 | 0.83 | 2.1e-03 |
| PyOMP (OpenMP) | 16 | 0.7902 | 12.29 | 0.77 | 2.1e-03 |
| PyOMP (OpenMP) | 24 | 0.5097 | 19.05 | 0.79 | 2.1e-03 |
| PyOMP (OpenMP) | 48 | 0.4708 | 20.62 | 0.43 | 2.1e-03 |
| Python threads (nogil) | 1 | 9.7192 | 1.00 | 1.00 | 2.1e-03 |
| Python threads (nogil) | 2 | 4.9120 | 1.98 | 0.99 | 2.1e-03 |
| Python threads (nogil) | 4 | 2.5165 | 3.86 | 0.96 | 2.1e-03 |
| Python threads (nogil) | 8 | 1.4041 | 6.92 | 0.86 | 2.1e-03 |
| Python threads (nogil) | 12 | 0.9703 | 10.01 | 0.83 | 2.1e-03 |
| Python threads (nogil) | 16 | 0.7509 | 12.93 | 0.81 | 2.1e-03 |
| Python threads (nogil) | 24 | 0.5264 | 18.45 | 0.77 | 2.1e-03 |
| Python threads (nogil) | 48 | 0.4685 | 20.73 | 0.43 | 2.1e-03 |
| multiprocessing | 1 | 9.7831 | 0.99 | 0.99 | 2.1e-03 |
| multiprocessing | 2 | 4.9181 | 1.97 | 0.99 | 2.1e-03 |
| multiprocessing | 4 | 2.5852 | 3.76 | 0.94 | 2.1e-03 |
| multiprocessing | 8 | 1.4306 | 6.79 | 0.85 | 2.1e-03 |
| multiprocessing | 12 | 1.0309 | 9.42 | 0.78 | 2.1e-03 |
| multiprocessing | 16 | 0.7573 | 12.82 | 0.80 | 2.1e-03 |
| multiprocessing | 24 | 0.5852 | 16.59 | 0.69 | 2.1e-03 |
| multiprocessing | 48 | 0.4791 | 20.27 | 0.42 | 2.1e-03 |

## Rossler - library (N=20000000 samples, degree 5 (56 candidate terms))

Numba serial: 50.0012 s
 | PySINDy serial: 278.4085 s (compiled serial is 5.6x faster)


| backend | cores | time [s] | speed-up S | efficiency E | max coef. error |
|---|---:|---:|---:|---:|---:|
| Numba prange | 1 | 49.7796 | 1.00 | 1.00 | 7.2e-04 |
| Numba prange | 2 | 27.2144 | 1.84 | 0.92 | 7.2e-04 |
| Numba prange | 4 | 14.4229 | 3.47 | 0.87 | 7.2e-04 |
| Numba prange | 8 | 7.9903 | 6.26 | 0.78 | 7.2e-04 |
| Numba prange | 12 | 5.5049 | 9.08 | 0.76 | 7.2e-04 |
| Numba prange | 16 | 4.0937 | 12.21 | 0.76 | 7.2e-04 |
| Numba prange | 24 | 2.8505 | 17.54 | 0.73 | 7.2e-04 |
| Numba prange | 48 | 2.5252 | 19.80 | 0.41 | 7.2e-04 |
| PyOMP (OpenMP) | 1 | 50.3859 | 0.99 | 0.99 | 7.2e-04 |
| PyOMP (OpenMP) | 2 | 28.4548 | 1.76 | 0.88 | 7.2e-04 |
| PyOMP (OpenMP) | 4 | 14.8622 | 3.36 | 0.84 | 7.2e-04 |
| PyOMP (OpenMP) | 8 | 8.2264 | 6.08 | 0.76 | 7.2e-04 |
| PyOMP (OpenMP) | 12 | 5.6939 | 8.78 | 0.73 | 7.2e-04 |
| PyOMP (OpenMP) | 16 | 4.5196 | 11.06 | 0.69 | 7.2e-04 |
| PyOMP (OpenMP) | 24 | 3.1247 | 16.00 | 0.67 | 7.2e-04 |
| PyOMP (OpenMP) | 48 | 2.7448 | 18.22 | 0.38 | 7.2e-04 |
| Python threads (nogil) | 1 | 49.9058 | 1.00 | 1.00 | 7.2e-04 |
| Python threads (nogil) | 2 | 25.0618 | 2.00 | 1.00 | 7.2e-04 |
| Python threads (nogil) | 4 | 12.8503 | 3.89 | 0.97 | 7.2e-04 |
| Python threads (nogil) | 8 | 7.0125 | 7.13 | 0.89 | 7.2e-04 |
| Python threads (nogil) | 12 | 4.8547 | 10.30 | 0.86 | 7.2e-04 |
| Python threads (nogil) | 16 | 3.6698 | 13.63 | 0.85 | 7.2e-04 |
| Python threads (nogil) | 24 | 2.4688 | 20.25 | 0.84 | 7.2e-04 |
| Python threads (nogil) | 48 | 2.3815 | 21.00 | 0.44 | 7.2e-04 |
| multiprocessing | 1 | 49.5321 | 1.01 | 1.01 | 7.2e-04 |
| multiprocessing | 2 | 25.1768 | 1.99 | 0.99 | 7.2e-04 |
| multiprocessing | 4 | 12.5859 | 3.97 | 0.99 | 7.2e-04 |
| multiprocessing | 8 | 7.3828 | 6.77 | 0.85 | 7.2e-04 |
| multiprocessing | 12 | 4.9318 | 10.14 | 0.84 | 7.2e-04 |
| multiprocessing | 16 | 3.7521 | 13.33 | 0.83 | 7.2e-04 |
| multiprocessing | 24 | 2.5027 | 19.98 | 0.83 | 7.2e-04 |
| multiprocessing | 48 | 2.4077 | 20.77 | 0.43 | 7.2e-04 |
[guillenrondonp@login results_node]$ 
