"""
backends_numba.py
=================
Four ways of running the SAME SINDy kernels (sindy_core.py) on p cores:

  serial      : numba.njit, one core (the reference for speed-up)
  numba       : numba.njit(parallel=True) + prange   (shared memory threads;
                with NUMBA_THREADING_LAYER=omp this IS an OpenMP runtime)
  threads     : concurrent.futures.ThreadPoolExecutor calling njit(nogil=True)
                kernels -> real parallel Python threads, no GIL contention
  processes   : multiprocessing.Pool, one interpreter per core
                (data in shared memory for the large single-trajectory case)

Two workloads:

  ensemble  (task parallelism): M trajectories (random initial conditions),
            each one integrated with RK4 and identified with SINDy.
  library   (data parallelism): ONE long trajectory with N samples; the
            expensive part, Theta(X) and Theta^T Theta, Theta^T dX, is split
            into row blocks whose partial sums are reduced, then STLSQ.
"""
import os
import multiprocessing as mp
from concurrent.futures import ThreadPoolExecutor
from multiprocessing import shared_memory

import numpy as np
import numba
from numba import njit, prange

from sindy_core import build_kernels

K = build_kernels(njit(nogil=True))
sindy_one = K["sindy_one"]
library_gram_chunk = K["library_gram_chunk"]
symmetrize = K["symmetrize"]
stlsq_from_normal_eq = K["stlsq_from_normal_eq"]
solve_checked = K["solve_checked"]

BLOCK = 4096           # rows per block in the data-parallel workload


# ============================================================================
# Workload 1: ensemble of trajectories (task parallelism)
# ============================================================================
@njit(nogil=True)
def ensemble_serial(system, p, x0s, dt, n, expo, thr):
    M = x0s.shape[0]
    out = np.empty((M, expo.shape[0], 3))
    for t in range(M):
        out[t] = sindy_one(system, p, x0s[t], dt, n, expo, thr)
    return out


@njit(parallel=True)
def ensemble_prange(system, p, x0s, dt, n, expo, thr):
    M = x0s.shape[0]
    out = np.empty((M, expo.shape[0], 3))
    for t in prange(M):                      # each thread takes trajectories
        out[t] = sindy_one(system, p, x0s[t], dt, n, expo, thr)
    return out


def ensemble_threads(system, p, x0s, dt, n, expo, thr, nthreads, pool=None):
    chunks = np.array_split(np.arange(x0s.shape[0]), nthreads)
    own = pool is None
    pool = pool or ThreadPoolExecutor(nthreads)
    futs = [pool.submit(ensemble_serial, system, p, x0s[c], dt, n, expo, thr)
            for c in chunks if len(c)]
    res = np.concatenate([f.result() for f in futs])
    if own:
        pool.shutdown()
    return res


def _ens_worker(args):
    return ensemble_serial(*args)


def ensemble_processes(system, p, x0s, dt, n, expo, thr, nproc, pool):
    chunks = np.array_split(np.arange(x0s.shape[0]), nproc)
    args = [(system, p, x0s[c], dt, n, expo, thr) for c in chunks if len(c)]
    return np.concatenate(pool.map(_ens_worker, args))


# ============================================================================
# Workload 2: one long trajectory, data-parallel library + normal equations
# ============================================================================
@njit(nogil=True)
def gram_blocks(X, dX, expo, b0, b1, block, G, R):
    """Accumulate blocks b0..b1-1 into G, R (one thread / process)."""
    n = X.shape[0]
    for b in range(b0, b1):
        i0 = b * block
        i1 = min(n, i0 + block)
        library_gram_chunk(X, dX, expo, i0, i1, G, R)


@njit(nogil=True)
def library_serial_fit(X, dX, expo, thr):
    m = expo.shape[0]
    G = np.zeros((m, m)); R = np.zeros((m, 3))
    nb = (X.shape[0] + BLOCK - 1) // BLOCK
    gram_blocks(X, dX, expo, 0, nb, BLOCK, G, R)
    symmetrize(G)
    return solve_checked(G, R, X, dX, expo, thr)


@njit(parallel=True)
def library_prange_fit(X, dX, expo, thr, nparts):
    """nparts private partial sums (one per thread) + a final reduction."""
    m = expo.shape[0]
    nb = (X.shape[0] + BLOCK - 1) // BLOCK
    Gp = np.zeros((nparts, m, m)); Rp = np.zeros((nparts, m, 3))
    for t in prange(nparts):
        b0 = (nb * t) // nparts
        b1 = (nb * (t + 1)) // nparts
        gram_blocks(X, dX, expo, b0, b1, BLOCK, Gp[t], Rp[t])
    G = Gp.sum(axis=0); R = Rp.sum(axis=0)
    symmetrize(G)
    return solve_checked(G, R, X, dX, expo, thr)


def _split_blocks(n, parts):
    nb = (n + BLOCK - 1) // BLOCK
    return [((nb * t) // parts, (nb * (t + 1)) // parts) for t in range(parts)]


def library_threads_fit(X, dX, expo, thr, nthreads, pool):
    m = expo.shape[0]

    def work(rng):
        G = np.zeros((m, m)); R = np.zeros((m, 3))
        gram_blocks(X, dX, expo, rng[0], rng[1], BLOCK, G, R)   # GIL released
        return G, R

    parts = list(pool.map(work, _split_blocks(X.shape[0], nthreads)))
    G = sum(g for g, _ in parts); R = sum(r for _, r in parts)
    symmetrize(G)
    return solve_checked(G, R, X, dX, expo, thr)


# --- processes: X and dX live in shared memory, workers attach once ---------
_SHM = {}


def _attach(names, shape):
    for key, name in names.items():
        shm = shared_memory.SharedMemory(name=name)
        _SHM[key] = (shm, np.ndarray(shape, dtype=np.float64, buffer=shm.buf))


def _lib_worker(args):
    b0, b1, expo = args
    X, dX = _SHM["X"][1], _SHM["dX"][1]
    m = expo.shape[0]
    G = np.zeros((m, m)); R = np.zeros((m, 3))
    gram_blocks(X, dX, expo, b0, b1, BLOCK, G, R)
    return G, R


class SharedTrajectory:
    """Copy X, dX once into shared memory and start a pool attached to it."""

    def __init__(self, X, dX, nproc, ctx):
        self.blocks = []
        names = {}
        for key, arr in (("X", X), ("dX", dX)):
            shm = shared_memory.SharedMemory(create=True, size=arr.nbytes)
            np.ndarray(arr.shape, dtype=np.float64, buffer=shm.buf)[:] = arr
            self.blocks.append(shm)
            names[key] = shm.name
        self.n = X.shape[0]
        self.pool = ctx.Pool(nproc, initializer=_attach, initargs=(names, X.shape))
        self.nproc = nproc

    def fit(self, expo, thr, X, dX):
        tasks = [(b0, b1, expo) for b0, b1 in _split_blocks(self.n, self.nproc)]
        parts = self.pool.map(_lib_worker, tasks)
        G = sum(g for g, _ in parts); R = sum(r for _, r in parts)
        symmetrize(G)
        return solve_checked(G, R, X, dX, expo, thr)

    def close(self):
        self.pool.close(); self.pool.join()
        for shm in self.blocks:
            shm.close(); shm.unlink()


def mp_context():
    # fork is fastest on Linux; macOS/Windows need spawn (kernels are then
    # compiled once per worker during the warm-up call, not during timing).
    # Override with SINDY_MP_START=fork|spawn|forkserver.
    method = os.environ.get("SINDY_MP_START")
    if not method:
        method = "fork" if os.name == "posix" and os.uname().sysname == "Linux" else "spawn"
    return mp.get_context(method)
