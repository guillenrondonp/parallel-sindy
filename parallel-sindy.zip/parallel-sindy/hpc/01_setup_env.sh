#!/bin/bash
# ---------------------------------------------------------------------------
# 01_setup_env.sh -- create the Python environment ONCE on the login node.
#   bash hpc/01_setup_env.sh
#
# Module names differ between clusters: check `module avail` (or the output
# of 00_check_node.sbatch) and edit the two `module load` lines below.
#
# mpi4py MUST be compiled against the cluster's own MPI so that srun and the
# Omni-Path network are used. Do not install mpi4py/openmpi from conda-forge.
# ---------------------------------------------------------------------------
set -e

module purge
module load anaconda3        # or: miniconda / miniforge / python  (edit!)
module load openmpi          # or: intel-mpi / mvapich2 / impi    (edit!)

ENV=sindy
conda create -y -n $ENV -c conda-forge python=3.12 numpy numba matplotlib
source "$(conda info --base)/etc/profile.d/conda.sh"
conda activate $ENV

pip install pysindy
# PyOMP (Linux x86-64 is supported); skip silently if it cannot be installed
conda install -y -c python-for-hpc -c conda-forge pyomp || echo "PyOMP not installed (optional)"

# mpi4py built from source against the loaded MPI (uses its mpicc)
MPICC=$(which mpicc) pip install --no-cache-dir --no-binary=mpi4py mpi4py

python - <<'EOF'
import numpy, numba, pysindy
from mpi4py import MPI
print("numpy", numpy.__version__, "| numba", numba.__version__, "| pysindy", pysindy.__version__)
print("MPI:", MPI.Get_library_version().splitlines()[0])
try:
    from numba.openmp import njit; print("PyOMP: ok")
except Exception as e:
    print("PyOMP: not available ->", e)
EOF
echo "Environment '$ENV' ready."
