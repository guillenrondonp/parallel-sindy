#!/bin/bash
# Submit the whole study:  bash hpc/submit_all.sh            (1..16 nodes)
#                          NODES="1 2 4 8 16 32" bash hpc/submit_all.sh
# Run 00_check_node.sbatch and 01_setup_env.sh first.
NODES=${NODES:-"1 2 4 8 16"}
mkdir -p results_hpc
sbatch hpc/10_single_node.sbatch
for N in $NODES; do
  sbatch --nodes=$N hpc/20_mpi_strong.sbatch
  sbatch --nodes=$N hpc/21_mpi_weak.sbatch
done
squeue -u "$USER"
echo "When all jobs finish:  python hpc/collect_hpc.py"
