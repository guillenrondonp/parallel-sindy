"""
collect_hpc.py -- turn the cluster results into tables and figures.

    python hpc/collect_hpc.py [results_hpc]

Reads  results_hpc/mpi_strong.jsonl, results_hpc/mpi_weak.jsonl
Writes results_hpc/summary_hpc.md, mpi_strong_speedup.png,
       mpi_strong_efficiency.png, mpi_weak_efficiency.png
(The single-node shared-memory study is summarised by benchmark.py itself in
 results_hpc/single_node/.)

Speed-up and efficiency are relative to the 1-core (1 rank, 1 thread) run of
the same system and workload: S(p) = T(1)/T(p), E(p) = S(p)/p;
weak-scaling efficiency is E_w(p) = T(1)/T(p) with work per core fixed.
Repeated runs of the same configuration keep the fastest one.
"""
import json
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import ScalarFormatter

D = Path(sys.argv[1] if len(sys.argv) > 1 else "results_hpc")
NAME = {"lorenz": "Lorenz", "rossler": "Rössler"}
STY = {"mpi": dict(color="#2a6fdb", marker="o", label="pure MPI"),
       "mpi+threads": dict(color="#d1495b", marker="s", label="hybrid MPI + threads")}


def load(fname):
    f = D / fname
    if not f.exists():
        return []
    best = {}
    for line in f.read_text().splitlines():
        if not line.strip():
            continue
        r = json.loads(line)
        k = (r["system"], r["workload"], r["backend"], r["cores"], r["threads"])
        if k not in best or r["time_best"] < best[k]["time_best"]:
            best[k] = r
    return list(best.values())


def base(rs, s, w):
    b = [r for r in rs if r["system"] == s and r["workload"] == w and r["cores"] == 1]
    return min(b, key=lambda r: r["time_best"])["time_best"] if b else None


def series(rs, s, w, backend):
    return sorted([r for r in rs if r["system"] == s and r["workload"] == w
                   and (r["backend"] == backend or (r["cores"] == 1 and backend == "mpi+threads"))],
                  key=lambda r: r["cores"])


def plot(rs, kind, fname, weak=False):
    fig, axes = plt.subplots(2, 2, figsize=(9, 6.6))
    for i, w in enumerate(("ensemble", "library")):
        for j, s in enumerate(("lorenz", "rossler")):
            ax = axes[i, j]
            T1 = base(rs, s, w)
            if T1 is None:
                ax.set_visible(False); continue
            allp = sorted({r["cores"] for r in rs if r["system"] == s and r["workload"] == w})
            for b in (["mpi"] if weak else ["mpi", "mpi+threads"]):
                ser = series(rs, s, w, b)
                if len(ser) < 2 and b == "mpi+threads":
                    continue
                p = [r["cores"] for r in ser]
                if weak or kind == "efficiency":
                    y = [T1 / r["time_best"] / (1 if weak else r["cores"]) for r in ser]
                else:
                    y = [T1 / r["time_best"] for r in ser]
                ax.plot(p, y, lw=1.8, ms=5, **STY[b])
            ax.set_xscale("log", base=2)
            if kind == "speedup" and not weak:
                ax.set_yscale("log", base=2)
                ax.yaxis.set_major_formatter(ScalarFormatter())
                ax.plot(allp, allp, "k--", lw=1, label="ideal")
                ax.set_ylabel("speed-up S(p)")
            else:
                ax.axhline(1, color="k", ls="--", lw=1, label="ideal")
                ax.set_ylim(0, 1.15)
                ax.set_ylabel("weak-scaling efficiency T(1)/T(p)" if weak else "efficiency E(p)")
            nodes_ticks = [p for p in allp]
            ax.set_xticks(nodes_ticks); ax.set_xticklabels([str(p) for p in nodes_ticks], fontsize=7)
            ax.set_xlabel("cores p")
            ax.set_title(f"{NAME[s]} – {w}")
            ax.grid(alpha=0.3, which="both")
            if i == 0 and j == 0:
                ax.legend(fontsize=8, frameon=False)
    fig.tight_layout(); fig.savefig(D / fname, dpi=200); plt.close(fig)


def table(rs, title, weak=False):
    out = [f"\n## {title}\n"]
    for s in ("lorenz", "rossler"):
        for w in ("ensemble", "library"):
            T1 = base(rs, s, w)
            sub = sorted([r for r in rs if r["system"] == s and r["workload"] == w],
                         key=lambda r: (r["cores"], r["backend"]))
            if not sub or T1 is None:
                continue
            size = f"M={sub[0].get('M')}" if w == "ensemble" else f"N={sub[0].get('N')}"
            out.append(f"\n### {NAME[s]} – {w} ({size} at p=1)\n")
            out.append("| backend | nodes | ranks | threads | cores | time [s] | comm [s] | "
                       + ("E_weak |" if weak else "S | E |") + " max coef err |")
            out.append("|---|--:|--:|--:|--:|--:|--:|" + ("--:|" if weak else "--:|--:|") + "--:|")
            for r in sub:
                S = T1 / r["time_best"]
                eff = f"{S:.2f} |" if weak else f"{S:.1f} | {S / r['cores']:.2f} |"
                out.append(f"| {r['backend']} | {r['nodes']} | {r['ranks']} | {r['threads']} | {r['cores']} | "
                           f"{r['time_best']:.3f} | {r['time_comm']:.4f} | {eff} {r['max_coef_error']:.1e} |")
    return out


if __name__ == "__main__":
    strong, weak = load("mpi_strong.jsonl"), load("mpi_weak.jsonl")
    md = ["# SINDy on the UHD HPC cluster – MPI results"]
    if strong:
        plot(strong, "speedup", "mpi_strong_speedup.png")
        plot(strong, "efficiency", "mpi_strong_efficiency.png")
        md += table(strong, "Strong scaling (fixed total size)")
    if weak:
        plot(weak, "weak", "mpi_weak_efficiency.png", weak=True)
        md += table(weak, "Weak scaling (fixed size per core)", weak=True)
    (D / "summary_hpc.md").write_text("\n".join(md) + "\n")
    print(f"wrote {D}/summary_hpc.md and figures ({len(strong)} strong, {len(weak)} weak records)")
