# Running parallel SINDy on the UHD HPC cluster

> **Experimental / future work.** The paper uses a single node (`hpc/run_node.sbatch`).
> The MPI scripts below (`run_mpi.py`, `20_mpi_strong`, `21_mpi_weak`, `collect_hpc.py`) are
> a tested but not yet benchmarked multi-node extension.

UHD cluster (per uhd.edu): 32 compute nodes, Intel Xeon E5-2650 v4,
"48 cores" and 256 GB per node, Omni-Path 100 Gb/s, shared NFS, Slurm.
The E5-2650 v4 has 12 cores, so a node is most likely
**2 sockets × 12 cores = 24 physical cores (48 hardware threads)**.
Step 1 checks this; all scripts detect the real value automatically.

## Steps

```bash
# 0. copy the repository to your home directory on the cluster, then:
sbatch hpc/00_check_node.sbatch        # hardware + module names (1 min)
#    edit the two `module load` lines in hpc/01_setup_env.sh and hpc/env.sh
#    and the `#SBATCH --partition` line in the .sbatch files if needed
bash hpc/01_setup_env.sh               # conda env with numba, pysindy, pyomp, mpi4py

# 1. quick test (2 minutes)
srun -N 1 -n 4 --time=00:10:00 python run_mpi.py --workload library --N 2000000 --show

# 2. full study
bash hpc/submit_all.sh                 # 1, 2, 4, 8, 16 nodes
python hpc/collect_hpc.py              # tables + figures in results_hpc/
```

## What each job measures

| job | scope | back ends | core counts | problem size |
|---|---|---|---|---|
| `10_single_node` | 1 node, shared memory | prange, threads, multiprocessing, PyOMP, PySINDy | 1, 2, 4, 8, 12, 16, 24 (+48 HT) | ensemble M=960; library N=2·10⁷ |
| `20_mpi_strong` | 1–16 nodes, fixed total size | pure MPI; hybrid MPI + threads | 1 … 384 | ensemble M=3840; library N=10⁸ |
| `21_mpi_weak` | 1–16 nodes, fixed size per core | pure MPI | 1 … 384 | 10 trajectories / core; 10⁶ samples / core |

* Strong-scaling speed-up is relative to the 1-core run of the same size.
* `--hint=nomultithread --cpu-bind=cores` puts one rank per physical core.
* Hybrid mode uses one MPI rank per socket and 12 Numba threads per rank
  (keeps each rank's memory on its own NUMA domain).
* Data generation and distribution are not timed; the reported time is
  library construction + Allreduce + STLSQ (library) or the identification
  of all trajectories + Gather (ensemble). `time_comm` isolates the MPI part.

## Estimated cost

About 5 h (single node) + 3 h (1-node strong, dominated by the 1-core
baseline) + < 1 h for each multi-node job: roughly 30 node-hours in total.
Ask HPC support whether 16-node jobs need a special partition or reservation.
To include the whole cluster: `NODES="1 2 4 8 16 32" bash hpc/submit_all.sh`.
