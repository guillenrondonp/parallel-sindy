# Sourced by every job script. Edit the module names to match 01_setup_env.sh.
module purge
module load anaconda3        # edit!
module load openmpi          # edit!
source "$(conda info --base)/etc/profile.d/conda.sh"
conda activate sindy

# physical cores per node (not hyper-threads), unless set by the user
export CPN=${CPN:-$(lscpu -p=CORE,SOCKET | grep -v '^#' | sort -u | wc -l)}
export SPN=${SPN:-$(lscpu -p=SOCKET | grep -v '^#' | sort -u | wc -l)}   # sockets per node
export OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export NUMBA_CACHE_DIR=${TMPDIR:-/tmp}/numba_cache_$USER
cd "$SLURM_SUBMIT_DIR"
mkdir -p results_hpc
echo "host=$(hostname) nodes=${SLURM_NNODES:-1} CPN=$CPN SPN=$SPN"
