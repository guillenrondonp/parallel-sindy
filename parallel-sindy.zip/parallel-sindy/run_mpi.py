"""
run_mpi.py
==========
Distributed-memory SINDy with MPI (mpi4py), for runs that span several nodes
of a cluster. Launch with srun (Slurm) or mpirun:

    srun -n 96 python run_mpi.py --system lorenz --workload library --N 100000000
    mpirun -n 4 python run_mpi.py --system rossler --workload ensemble --M 384

Each MPI rank runs the same compiled kernels as the shared-memory back ends
(sindy_core.py), optionally with Numba prange threads inside the rank
(--threads T, "hybrid MPI + threads"). Cores used = ranks x T.

ensemble (task parallel): the M initial conditions are split into contiguous
    chunks, each rank identifies its trajectories, coefficients are gathered.
library (data parallel): the rows of the long trajectory are split among the
    ranks; each rank accumulates its local G = Theta^T Theta and
    R = Theta^T dX, one MPI_Allreduce sums them (only m*m + 3m doubles,
    independent of N), and every rank solves the same small STLSQ problem.

Data placement for the library workload (--data):
    scatter : rank 0 integrates the whole trajectory and scatters row blocks
              (identical data for every rank count -> clean strong scaling)
    local   : every rank integrates its own trajectory segment from a different
              initial condition (no communication, memory distributed ->
              weak scaling to very large N)
Data generation and distribution are NOT timed, as in benchmark.py.

Weak scaling: --weak makes M and N "per rank x threads" quantities.

Rank 0 prints one JSON line (also appended to --out if given) with the best
time, the split compute / communication time, accuracy, ranks, threads, nodes.
"""
import argparse
import json
import os
import sys
import time

ap = argparse.ArgumentParser()
ap.add_argument("--system", choices=["lorenz", "rossler"], default="lorenz")
ap.add_argument("--workload", choices=["ensemble", "library"], default="library")
ap.add_argument("--threads", type=int, default=1, help="Numba prange threads per rank")
ap.add_argument("--repeats", type=int, default=3)
ap.add_argument("--M", type=int, default=960, help="ensemble: trajectories (per core with --weak)")
ap.add_argument("--n", type=int, default=20000, help="ensemble: samples per trajectory")
ap.add_argument("--N", type=int, default=20_000_000, help="library: samples (per core with --weak)")
ap.add_argument("--ens-degree", type=int, default=3)
ap.add_argument("--lib-degree", type=int, default=5)
ap.add_argument("--data", choices=["scatter", "local"], default="scatter")
ap.add_argument("--weak", action="store_true", help="weak scaling: sizes are per core")
ap.add_argument("--out", default=None, help="append the JSON line to this file")
ap.add_argument("--show", action="store_true")
args = ap.parse_args()

T = max(1, args.threads)
os.environ["NUMBA_NUM_THREADS"] = str(T)
os.environ["OMP_NUM_THREADS"] = "1"
for v in ("OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "VECLIB_MAXIMUM_THREADS"):
    os.environ[v] = "1"

import numpy as np  # noqa: E402
from mpi4py import MPI  # noqa: E402
import numba  # noqa: E402
from numba import njit, prange  # noqa: E402

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sindy_core import (SYSTEMS, DEFAULT_PARAMS, DEFAULT_DT, DEFAULT_THRESHOLD,  # noqa: E402
                        exponent_table, true_coefficients, format_equations,
                        initial_conditions)
import backends_numba as B  # noqa: E402

comm = MPI.COMM_WORLD
rank, P = comm.Get_rank(), comm.Get_size()
cores = P * T
hosts = comm.gather(MPI.Get_processor_name(), root=0)
nodes = len(set(hosts)) if rank == 0 else None
if T > 1:
    numba.set_num_threads(T)

system = args.system
sid, prm = SYSTEMS[system], DEFAULT_PARAMS[system]
dt, thr = DEFAULT_DT[system], DEFAULT_THRESHOLD[system]
degree = args.ens_degree if args.workload == "ensemble" else args.lib_degree
expo = exponent_table(3, degree)
m = expo.shape[0]
truth = true_coefficients(system, expo)
BLOCK = B.BLOCK


@njit(parallel=True)
def gram_prange(X, dX, expo, nparts):
    """Local G, R with nparts threads (no STLSQ): hybrid MPI + threads."""
    m = expo.shape[0]
    nb = (X.shape[0] + BLOCK - 1) // BLOCK
    Gp = np.zeros((nparts, m, m)); Rp = np.zeros((nparts, m, 3))
    for t in prange(nparts):
        B.gram_blocks(X, dX, expo, (nb * t) // nparts, (nb * (t + 1)) // nparts, BLOCK, Gp[t], Rp[t])
    return Gp.sum(axis=0), Rp.sum(axis=0)


def local_gram(X, dX):
    if T == 1:
        G = np.zeros((m, m)); R = np.zeros((m, 3))
        B.gram_blocks(X, dX, expo, 0, (X.shape[0] + BLOCK - 1) // BLOCK, BLOCK, G, R)
        return G, R
    return gram_prange(X, dX, expo, T)


def split(total, parts):
    """Contiguous block sizes and offsets (first blocks get the remainder)."""
    q, r = divmod(total, parts)
    counts = np.array([q + (1 if i < r else 0) for i in range(parts)], dtype=np.int64)
    return counts, np.concatenate(([0], np.cumsum(counts)[:-1]))


# ---------------------------------------------------------------------------
if args.workload == "ensemble":
    M = args.M * cores if args.weak else args.M
    counts, offs = split(M, P)
    x0_all = initial_conditions(system, M, seed=1)
    x0_loc = np.ascontiguousarray(x0_all[offs[rank]:offs[rank] + counts[rank]])
    n = args.n

    def compute():
        if len(x0_loc) == 0:
            return np.empty((0, m, 3))
        if T == 1:
            return B.ensemble_serial(sid, prm, x0_loc, dt, n, expo, thr)
        return B.ensemble_prange(sid, prm, x0_loc, dt, n, expo, thr)

    def run():
        comm.Barrier(); t0 = MPI.Wtime()
        Xi_loc = compute()
        t1 = MPI.Wtime()
        recv = np.empty((M, m, 3)) if rank == 0 else None
        comm.Gatherv(Xi_loc, [recv, counts * m * 3, offs * m * 3, MPI.DOUBLE] if rank == 0 else None, root=0)
        t2 = MPI.Wtime()
        tc = comm.allreduce(t1 - t0, op=MPI.MAX)           # slowest rank's compute
        comm.Barrier(); t3 = MPI.Wtime()
        return recv, t3 - t0, tc
    size = dict(M=M, n=n)

# ---------------------------------------------------------------------------
else:
    N = args.N * cores if args.weak else args.N
    counts, offs = split(N, P)
    if args.data == "scatter":
        if rank == 0:
            x0 = initial_conditions(system, 1, seed=7)[0]
            Xg = B.K["integrate_rk4"](sid, prm, x0, dt, N)
            dXg = B.K["central_diff"](Xg, dt)
        else:
            Xg = dXg = None
        X = np.empty((counts[rank], 3)); dX = np.empty((counts[rank], 3))
        spec = [counts * 3, offs * 3]
        comm.Scatterv([Xg, spec[0], spec[1], MPI.DOUBLE] if rank == 0 else None, X, root=0)
        comm.Scatterv([dXg, spec[0], spec[1], MPI.DOUBLE] if rank == 0 else None, dX, root=0)
        del Xg, dXg
    else:   # local: own segment, discard a transient so it lies on the attractor
        x0 = initial_conditions(system, P, seed=7)[rank]
        burn = int(round(20.0 / dt))
        Xb = B.K["integrate_rk4"](sid, prm, x0, dt, burn + counts[rank])
        X = np.ascontiguousarray(Xb[burn:]); del Xb
        dX = B.K["central_diff"](X, dt)

    def run():
        comm.Barrier(); t0 = MPI.Wtime()
        G, R = local_gram(X, dX)
        t1 = MPI.Wtime()
        comm.Allreduce(MPI.IN_PLACE, G, op=MPI.SUM)
        comm.Allreduce(MPI.IN_PLACE, R, op=MPI.SUM)
        B.symmetrize(G)
        if B.K["gram_condition"](G) > 1e10:          # same decision on every rank
            Rloc = B.K["qr_reduce"](X, dX, expo, 0, X.shape[0], BLOCK)   # distributed TSQR
            Rall = np.empty((P,) + Rloc.shape)
            comm.Allgather(Rloc, Rall)
            Xi = B.K["stlsq_from_qr"](B.K["stack_qr"](Rall), m, thr, 1e-10, 25)
        else:
            Xi = B.stlsq_from_normal_eq(G, R, thr, 1e-10, 25)
        tc = comm.allreduce(t1 - t0, op=MPI.MAX)
        comm.Barrier(); t3 = MPI.Wtime()
        return Xi, t3 - t0, tc
    size = dict(N=N, data=args.data)

# ---------------------------------------------------------------------------
# warm-up on a tiny problem: triggers JIT compilation only (types, not sizes, matter)
if args.workload == "ensemble":
    xw = initial_conditions(system, 1, seed=99)
    (B.ensemble_serial if T == 1 else B.ensemble_prange)(sid, prm, xw, dt, 200, expo, thr)
else:
    k = min(len(X), 2 * BLOCK)
    Gw, Rw = local_gram(np.ascontiguousarray(X[:k]), np.ascontiguousarray(dX[:k]))
    B.symmetrize(Gw); B.stlsq_from_normal_eq(Gw + np.eye(m), Rw, thr, 1e-10, 25)
comm.Barrier()
best = None
for _ in range(args.repeats):
    res, tw, tc = run()
    if best is None or tw < best[1]:
        best = (res, tw, tc)

if rank == 0:
    res, tw, tc = best
    if args.workload == "ensemble":
        err = np.abs(res - truth[None]).max(axis=(1, 2))
        sup = np.all((res != 0) == (truth[None] != 0), axis=(1, 2))
        acc = dict(max_coef_error=float(err.max()), correct_support_fraction=float(sup.mean()))
        Xi_show = np.median(res, axis=0)
    else:
        acc = dict(max_coef_error=float(np.abs(res - truth).max()),
                   correct_support_fraction=float(np.all((res != 0) == (truth != 0))))
        Xi_show = res
    rec = dict(system=system, workload=args.workload,
               backend="mpi" if T == 1 else "mpi+threads",
               ranks=P, threads=T, cores=cores, nodes=nodes,
               scaling="weak" if args.weak else "strong",
               degree=degree, terms=int(m), time_best=tw,
               time_compute=tc, time_comm=max(tw - tc, 0.0), **size, **acc)
    line = json.dumps(rec)
    print(line, flush=True)
    if args.out:
        with open(args.out, "a") as f:
            f.write(line + "\n")
    if args.show:
        print(format_equations(Xi_show, expo), file=sys.stderr)
