"""
backends_pyomp.py
=================
True OpenMP in Python with PyOMP (https://github.com/Python-for-HPC/PyOMP):
``with openmp("parallel for ...")`` blocks are lowered by Numba/LLVM to the
same OpenMP runtime calls that a C compiler emits for ``#pragma omp ...``.

    pip install pyomp        # or: conda install -c python-for-hpc -c conda-forge pyomp

Keep this module in its own process: PyOMP and Numba's prange both start a
thread pool, and mixing them in one interpreter oversubscribes the cores.
"""
import numpy as np
from numba.openmp import njit, openmp_context as openmp
from numba.openmp import omp_set_num_threads, omp_get_num_threads, omp_get_thread_num

from sindy_core import build_kernels

K = build_kernels(njit)
sindy_one = K["sindy_one"]
library_gram_chunk = K["library_gram_chunk"]
symmetrize = K["symmetrize"]
stlsq_from_normal_eq = K["stlsq_from_normal_eq"]
solve_checked = K["solve_checked"]

BLOCK = 4096


# ---------------------------------------------------------------------------
# Workload 1: ensemble of trajectories
#   #pragma omp parallel for schedule(static)
#   for (t = 0; t < M; t++) Xi[t] = sindy_one(x0[t]);
# ---------------------------------------------------------------------------
@njit
def ensemble_omp(system, p, x0s, dt, n, expo, thr):
    M = x0s.shape[0]
    m = expo.shape[0]
    out = np.empty((M, m, 3))
    with openmp("parallel for schedule(static)"):
        for t in range(M):
            out[t] = sindy_one(system, p, x0s[t], dt, n, expo, thr)
    return out


# ---------------------------------------------------------------------------
# Workload 2: one long trajectory
#   #pragma omp parallel
#   { tid = omp_get_thread_num(); private partial sums G[tid], R[tid];
#     #pragma omp for
#     for (b = 0; b < nblocks; b++) accumulate(block b -> G[tid], R[tid]); }
#   reduce G, R; STLSQ
# ---------------------------------------------------------------------------
@njit
def library_omp_fit(X, dX, expo, thr, nthreads):
    m = expo.shape[0]
    n = X.shape[0]
    nb = (n + BLOCK - 1) // BLOCK
    Gp = np.zeros((nthreads, m, m))
    Rp = np.zeros((nthreads, m, 3))
    with openmp("parallel num_threads(nthreads)"):
        tid = omp_get_thread_num()
        with openmp("for schedule(static)"):
            for b in range(nb):
                i0 = b * BLOCK
                i1 = min(n, i0 + BLOCK)
                library_gram_chunk(X, dX, expo, i0, i1, Gp[tid], Rp[tid])
    G = Gp.sum(axis=0)
    R = Rp.sum(axis=0)
    symmetrize(G)
    return solve_checked(G, R, X, dX, expo, thr)


@njit
def report_threads():
    nt = 0
    with openmp("parallel shared(nt)"):
        with openmp("single"):
            nt = omp_get_num_threads()
    return nt
