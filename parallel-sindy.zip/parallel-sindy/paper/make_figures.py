"""
make_figures.py
===============
Reproduce every figure of the paper.

    python paper/make_figures.py [path/to/results.json]

Default results file: results_uhd/results.json (UHD HPC compute node,
2 x Intel Xeon E5-2650 v4, 24 cores / 48 hardware threads).
Identified coefficients are read from paper/figures/Xi_*.npy, written by
paper/verify_accuracy.py (library workload, N = 2e7, degree 5).
Figures are written to paper/figures/ as 300-dpi PNG.
"""
import json
import os
import sys
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
os.environ.setdefault("NUMBA_NUM_THREADS", "1")

from sindy_core import (SYSTEMS, DEFAULT_PARAMS, DEFAULT_DT, DEFAULT_THRESHOLD,  # noqa: E402
                        exponent_table, true_coefficients, initial_conditions,
                        format_equations)
import backends_numba as B  # noqa: E402

OUT = ROOT / "paper" / "figures"
OUT.mkdir(parents=True, exist_ok=True)
RES = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "results_uhd" / "results.json"

plt.rcParams.update({
    "font.family": "serif", "font.serif": ["Liberation Serif", "Times New Roman", "DejaVu Serif"],
    "mathtext.fontset": "stix", "font.size": 9, "axes.titlesize": 9.5,
    "axes.labelsize": 9, "legend.fontsize": 7.5, "xtick.labelsize": 8, "ytick.labelsize": 8,
    "axes.spines.top": False, "axes.spines.right": False, "savefig.dpi": 300,
})
C = {"numba": "#2a6fdb", "pyomp": "#d1495b", "threads": "#00a37a", "processes": "#e08e0b",
     "serial": "#444444", "pysindy": "#8c6bb1", "true": "#222222", "sindy": "#c03a2b"}
LAB = {"numba": "Numba prange", "pyomp": "PyOMP (OpenMP)", "threads": "Threads (nogil)", "processes": "multiprocessing"}
BACKENDS = ("numba", "pyomp", "threads", "processes")
NAME = {"lorenz": "Lorenz", "rossler": "Rössler"}
MK = {"numba": "o", "pyomp": "s", "threads": "^", "processes": "D"}


# ---------------------------------------------------------------------------
# Identified models (library workload, degree 5, N = 2e6, same as benchmark)
# ---------------------------------------------------------------------------
def identify(system, N=2_000_000, degree=5):
    sid, prm, dt, thr = SYSTEMS[system], DEFAULT_PARAMS[system], DEFAULT_DT[system], DEFAULT_THRESHOLD[system]
    expo = exponent_table(3, degree)
    x0 = initial_conditions(system, 1, seed=7)[0]
    X = B.K["integrate_rk4"](sid, prm, x0, dt, N)
    dX = B.K["central_diff"](X, dt)
    Xi = B.library_serial_fit(X, dX, expo, thr)
    return Xi, expo


def simulate_model(Xi, expo, x0, dt, n):
    """RK4 for xdot = Theta(x) Xi (identified or true model)."""
    def f(x):
        th = np.prod(x[None, :] ** expo, axis=1)
        return th @ Xi
    X = np.empty((n, 3)); X[0] = x0
    for i in range(n - 1):
        x = X[i]
        k1 = f(x); k2 = f(x + 0.5 * dt * k1); k3 = f(x + 0.5 * dt * k2); k4 = f(x + dt * k3)
        X[i + 1] = x + dt / 6 * (k1 + 2 * k2 + 2 * k3 + k4)
    return X


def fig_attractors(models):
    fig = plt.figure(figsize=(7.0, 5.0))
    setups = {"lorenz": (np.array([-8.0, 8.0, 27.0]), 0.005, 4000, 1600),
              "rossler": (np.array([1.0, 1.0, 0.0]), 0.01, 10000, 4000)}
    for col, system in enumerate(("lorenz", "rossler")):
        Xi, expo = models[system]
        x0, dt, n, nshow = setups[system]
        Xt = simulate_model(true_coefficients(system, expo), expo, x0, dt, n)
        Xs = simulate_model(Xi, expo, x0, dt, n)
        ax = fig.add_subplot(2, 2, col + 1, projection="3d")
        ax.plot(*Xt.T, color=C["true"], lw=0.5, label="true system")
        ax.plot(*Xs.T, color=C["sindy"], lw=0.5, ls="--", label="SINDy model")
        ax.set_title(f"({'ab'[col]}) {NAME[system]} attractor")
        ax.set_xlabel("$x$", labelpad=-6); ax.set_ylabel("$y$", labelpad=-6); ax.set_zlabel("$z$", labelpad=-6)
        ax.tick_params(pad=-2, labelsize=6)
        ax.view_init(22, -55 if system == "lorenz" else -60)
        if col == 0:
            ax.legend(loc="upper left", fontsize=7, frameon=False)
        ax2 = fig.add_subplot(2, 2, col + 3)
        t = np.arange(nshow) * dt
        ax2.plot(t, Xt[:nshow, 0], color=C["true"], lw=1.1, label="true $x(t)$")
        ax2.plot(t, Xs[:nshow, 0], color=C["sindy"], lw=1.1, ls="--", label="SINDy $x(t)$")
        ax2.set_xlabel("$t$"); ax2.set_ylabel("$x$")
        ax2.set_title(f"({'cd'[col]}) {NAME[system]}: $x(t)$, true vs identified")
        ax2.legend(frameon=False, loc="upper right" if system == "lorenz" else "lower left")
        ax2.grid(alpha=0.25)
    fig.tight_layout(h_pad=1.2)
    fig.savefig(OUT / "fig2_attractors.png"); plt.close(fig)


# ---------------------------------------------------------------------------
# Schematic: SINDy pipeline + two decompositions
# ---------------------------------------------------------------------------
def box(ax, x, y, w, h, text, fc, ec="#333", fs=8, bold=False):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.03",
                                fc=fc, ec=ec, lw=0.8))
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=fs,
            fontweight="bold" if bold else "normal")


def arrow(ax, x0, y0, x1, y1):
    ax.annotate("", xy=(x1, y1), xytext=(x0, y0),
                arrowprops=dict(arrowstyle="-|>", lw=0.8, color="#333", shrinkA=0, shrinkB=0))


def fig_schematic():
    fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.7), gridspec_kw={"width_ratios": [1.05, 1, 1]})
    for ax in axes:
        ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")

    ax = axes[0]
    ax.set_title("(a) SINDy pipeline", fontsize=9)
    steps = [("trajectory $X(t)$ (RK4)", "#e8eef9"), ("derivative $\\dot X$ (central FD)", "#e8eef9"),
             ("library $\\Theta(X)$ (monomials)", "#fdecd2"),
             ("$G=\\Theta^\\top\\Theta,\\; R=\\Theta^\\top\\dot X$", "#fdecd2"),
             ("STLSQ on $G\\,\\xi_k=R_{:,k}$", "#e3f4ec"), ("sparse $\\Xi$  $\\Rightarrow$  $\\dot x=\\Theta(x)\\Xi$", "#e3f4ec")]
    h, gap, y = 0.095, 0.05, 0.95
    for i, (s, fc) in enumerate(steps):
        box(ax, 0.06, y - h, 0.88, h, s, fc, fs=7.5)
        if i < len(steps) - 1:
            arrow(ax, 0.5, y - h, 0.5, y - h - gap)
        y -= h + gap
    ax.text(0.5, 0.02, "shaded orange: dominant cost $O(N m^2)$", ha="center", fontsize=6.8, style="italic")

    ax = axes[1]
    ax.set_title("(b) ensemble: task parallelism", fontsize=9)
    cols = ["#2a6fdb", "#00a37a", "#e08e0b", "#d1495b"]
    for k in range(4):
        y0 = 0.80 - k * 0.19
        box(ax, 0.02, y0, 0.36, 0.13, f"traj. {24*k+1}–{24*(k+1)}", "#f4f4f4", fs=7)
        box(ax, 0.47, y0, 0.25, 0.13, f"core {k+1}", cols[k] + "33", ec=cols[k], fs=7)
        box(ax, 0.80, y0, 0.18, 0.13, f"$\\Xi_{{{24*k+1}..}}$", "#e3f4ec", fs=7)
        arrow(ax, 0.38, y0 + 0.065, 0.47, y0 + 0.065); arrow(ax, 0.72, y0 + 0.065, 0.80, y0 + 0.065)
    ax.text(0.5, 0.06, "M independent SINDy fits;\nno communication between workers", ha="center", fontsize=6.8, style="italic")

    ax = axes[2]
    ax.set_title("(c) library: data parallelism", fontsize=9)
    for k in range(4):
        y0 = 0.80 - k * 0.19
        box(ax, 0.02, y0, 0.30, 0.13, f"rows block {k+1}", "#f4f4f4", fs=7)
        box(ax, 0.40, y0, 0.24, 0.13, f"$G_{k+1},R_{k+1}$", cols[k] + "33", ec=cols[k], fs=7)
        arrow(ax, 0.32, y0 + 0.065, 0.40, y0 + 0.065)
        arrow(ax, 0.64, y0 + 0.065, 0.72, 0.52)
    box(ax, 0.72, 0.44, 0.26, 0.16, "$\\sum_k G_k,\\sum_k R_k$\n+ STLSQ", "#e3f4ec", fs=7)
    ax.text(0.5, 0.06, "one long trajectory; private partial\nsums reduced, then one STLSQ", ha="center", fontsize=6.8, style="italic")
    fig.tight_layout(w_pad=0.6)
    fig.savefig(OUT / "fig1_schematic.png"); plt.close(fig)


# ---------------------------------------------------------------------------
# Benchmark figures from results.json
# ---------------------------------------------------------------------------
def _get(R, s, w, b):
    return sorted([r for r in R if r["system"] == s and r["workload"] == w and r["backend"] == b],
                  key=lambda r: r["cores"])


def fig_benchmark(R, kind, fname, phys=24):
    from matplotlib.ticker import FixedLocator, FixedFormatter, NullLocator
    fig, axes = plt.subplots(2, 2, figsize=(7.0, 5.0), sharex=True)
    for i, w in enumerate(("ensemble", "library")):
        for j, s in enumerate(("lorenz", "rossler")):
            ax = axes[i, j]
            T1 = _get(R, s, w, "serial")[0]["time_best"]
            P = sorted({r["cores"] for r in R if r["backend"] == "numba"})
            ax.axvspan(phys, max(P) * 1.08, color="#eeeeee", zorder=0)
            for b in BACKENDS:
                rs = _get(R, s, w, b)
                if not rs:
                    continue
                p = np.array([r["cores"] for r in rs]); t = np.array([r["time_best"] for r in rs])
                y = {"time": t, "speedup": T1 / t, "efficiency": T1 / t / p}[kind]
                ax.plot(p, y, marker=MK[b], color=C[b], lw=1.5, ms=4, label=LAB[b])
            if kind == "speedup":
                ax.plot(P, P, "k--", lw=0.9, label="ideal $S=p$")
                ax.set_ylim(0, 26)
            elif kind == "efficiency":
                ax.axhline(1, color="k", ls="--", lw=0.9, label="ideal $E=1$"); ax.set_ylim(0, 1.12)
            else:
                ps = _get(R, s, w, "pysindy")
                ax.axhline(T1, color=C["serial"], ls=":", lw=1.2, label="Numba serial")
                if ps:
                    ax.axhline(ps[0]["time_best"], color=C["pysindy"], ls="-.", lw=1.2, label="PySINDy")
                ax.set_yscale("log")
            ax.set_xscale("log", base=2)
            ax.xaxis.set_major_locator(FixedLocator(P)); ax.xaxis.set_major_formatter(FixedFormatter([str(p) for p in P]))
            ax.xaxis.set_minor_locator(NullLocator())
            ax.set_xlim(0.85, max(P) * 1.08)
            ax.text(phys * 1.05, 0.04 if kind != "time" else 0.9, "hyper-\nthreads", transform=ax.get_xaxis_transform(),
                    fontsize=6.5, color="#666666", va="bottom" if kind != "time" else "top")
            ax.set_title(f"({'abcd'[2*i+j]}) {NAME[s]} – {w}")
            ax.set_ylabel({"time": "wall time [s]", "speedup": "speed-up $S(p)$",
                           "efficiency": "efficiency $E(p)$"}[kind])
            if i == 1:
                ax.set_xlabel("number of workers $p$")
            ax.grid(alpha=0.25)
            if i == 0 and j == 0:
                ax.legend(frameon=False, ncol=1, fontsize=7,
                          loc="upper left" if kind == "speedup" else ("lower left" if kind == "efficiency" else "upper right"))
    fig.tight_layout()
    fig.savefig(OUT / fname); plt.close(fig)



def fig_scaling(R, fname, phys=24):
    """Speed-up (top row) and efficiency (bottom row) for the four cases."""
    from matplotlib.ticker import FixedLocator, FixedFormatter, NullLocator
    fig, axes = plt.subplots(2, 4, figsize=(7.2, 3.9), sharex=True)
    order = [("lorenz", "ensemble"), ("rossler", "ensemble"), ("lorenz", "library"), ("rossler", "library")]
    for j, (s, w) in enumerate(order):
        T1 = _get(R, s, w, "serial")[0]["time_best"]
        P = sorted({r["cores"] for r in R if r["backend"] == "numba"})
        for i, kind in enumerate(("speedup", "efficiency")):
            ax = axes[i, j]
            ax.axvspan(phys, max(P) * 1.1, color="#eeeeee", zorder=0)
            for b in BACKENDS:
                rs = _get(R, s, w, b)
                p = np.array([r["cores"] for r in rs]); t = np.array([r["time_best"] for r in rs])
                y = T1 / t if kind == "speedup" else T1 / t / p
                ax.plot(p, y, marker=MK[b], color=C[b], lw=1.2, ms=3, label=LAB[b])
            if kind == "speedup":
                ax.plot(P, P, "k--", lw=0.8, label="ideal")
                ax.set_ylim(0, 26)
                ax.set_title(f"{NAME[s]} – {w}", fontsize=8.5)
            else:
                ax.axhline(1, color="k", ls="--", lw=0.8); ax.set_ylim(0, 1.12)
                ax.set_xlabel("workers $p$", fontsize=8)
            ax.set_xscale("log", base=2)
            ax.xaxis.set_major_locator(FixedLocator([1, 2, 4, 8, 12, 24, 48]))
            ax.xaxis.set_major_formatter(FixedFormatter(["1", "2", "4", "8", "12", "24", "48"]))
            ax.xaxis.set_minor_locator(NullLocator())
            ax.tick_params(labelsize=6.5)
            ax.set_xlim(0.85, max(P) * 1.1)
            ax.grid(alpha=0.25)
            if j == 0:
                ax.set_ylabel("speed-up $S(p)$" if kind == "speedup" else "efficiency $E(p)$", fontsize=8)
    h, l = axes[0, 0].get_legend_handles_labels()
    fig.legend(h, l, loc="upper center", ncol=5, frameon=False, fontsize=7.5, bbox_to_anchor=(0.5, 1.01))
    fig.tight_layout(rect=(0, 0, 1, 0.95), h_pad=0.6, w_pad=0.4)
    fig.savefig(OUT / fname); plt.close(fig)


if __name__ == "__main__":
    models = {}
    for s in ("lorenz", "rossler"):
        expo = exponent_table(3, 5)
        f = OUT / f"Xi_{s}.npy"
        Xi = np.load(f) if f.exists() else identify(s, N=20_000_000)[0]
        models[s] = (Xi, expo)
        print(f"--- {s} (degree 5, N=2e7) ---\n{format_equations(Xi, expo, precision=4)}")
    fig_schematic()
    fig_attractors(models)
    R = json.loads(Path(RES).read_text())
    fig_scaling(R, "fig3_scaling.png")
    fig_benchmark(R, "speedup", "fig3_speedup.png")
    fig_benchmark(R, "efficiency", "fig4_efficiency.png")
    fig_benchmark(R, "time", "fig5_time.png")
    print("figures in", OUT)
