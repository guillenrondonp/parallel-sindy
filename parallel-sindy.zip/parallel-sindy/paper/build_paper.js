// build_paper.js — generates paper/Parallel_SINDy_Guillen-Rondon_2026.docx
// usage: node paper/build_paper.js [results.json] [accuracy.json]
const fs = require("fs");
const path = require("path");
const {
  Document, Packer, Paragraph, TextRun, ImageRun, Table, TableRow, TableCell,
  AlignmentType, HeadingLevel, WidthType, BorderStyle, ShadingType, TabStopType,
  Footer, PageNumber, LevelFormat, ExternalHyperlink,
} = require("docx");

const ROOT = path.resolve(__dirname, "..");
const FIG = path.join(__dirname, "figures");
const R = JSON.parse(fs.readFileSync(process.argv[2] || path.join(ROOT, "results_uhd", "results.json")));
// accuracy of the final solver (paper/verify_accuracy.py); falls back to results.json when absent
const ACCF = process.argv[3] || path.join(ROOT, "results_uhd", "accuracy_final_code.json");
const ACC = fs.existsSync(ACCF) ? JSON.parse(fs.readFileSync(ACCF)) : null;
const FONT = "Times New Roman";
const BASE = 21; // half-points (10.5 pt)

// ---------------------------------------------------------------- helpers
function get(s, w, b, p) {
  return R.find(r => r.system === s && r.workload === w && r.backend === b && (p === undefined || r.cores === p));
}
const T1 = (s, w) => get(s, w, "serial").time_best;
const f2 = x => x.toFixed(2), f3 = x => x.toFixed(3);

// inline markup: **bold**, *italic*, ^{sup}, _{sub}, `code`
function runs(text, o = {}) {
  const out = [];
  const re = /(\*\*[^*]+\*\*|\*[^*]+\*|\^\{[^}]+\}|_\{[^}]+\}|`[^`]+`)/g;
  let last = 0, m;
  const base = { font: FONT, size: o.size || BASE, bold: o.bold, italics: o.italics, color: o.color };
  while ((m = re.exec(text)) !== null) {
    if (m.index > last) out.push(new TextRun({ ...base, text: text.slice(last, m.index) }));
    const t = m[0];
    if (t.startsWith("**")) out.push(new TextRun({ ...base, text: t.slice(2, -2), bold: true }));
    else if (t.startsWith("*")) out.push(new TextRun({ ...base, text: t.slice(1, -1), italics: !o.italics }));
    else if (t.startsWith("^")) out.push(new TextRun({ ...base, text: t.slice(2, -1), superScript: true }));
    else if (t.startsWith("_")) out.push(new TextRun({ ...base, text: t.slice(2, -1), subScript: true }));
    else out.push(new TextRun({ ...base, text: t.slice(1, -1), font: "Courier New", size: (o.size || BASE) - 2 }));
    last = m.index + t.length;
  }
  if (last < text.length) out.push(new TextRun({ ...base, text: text.slice(last) }));
  return out;
}
const P = (text, o = {}) => new Paragraph({
  children: runs(text, o), alignment: o.align || AlignmentType.JUSTIFIED,
  spacing: { after: o.after ?? 100, before: o.before ?? 0, line: 252 },
  indent: o.indent ? { firstLine: 0 } : undefined,
});
const H1 = t => new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun({ text: t, font: FONT })], spacing: { before: 200, after: 90 } });
const H2 = t => new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun({ text: t, font: FONT })], spacing: { before: 130, after: 70 } });
let eqn = 0;
function EQ(text) {
  eqn += 1;
  return new Paragraph({
    tabStops: [{ type: TabStopType.CENTER, position: 4680 }, { type: TabStopType.RIGHT, position: 9360 }],
    spacing: { before: 50, after: 70 },
    children: [new TextRun({ text: "\t", font: FONT }), ...runs(text, { italics: true }),
      new TextRun({ text: `\t(${eqn})`, font: FONT, size: BASE })],
  });
}
function CODE(lines) {
  return lines.map((l, i) => new Paragraph({
    shading: { type: ShadingType.CLEAR, fill: "F3F4F6", color: "auto" },
    spacing: { after: i === lines.length - 1 ? 110 : 0, line: 220 },
    indent: { left: 200 },
    children: [new TextRun({ text: l === "" ? " " : l, font: "Courier New", size: 16 })],
  }));
}
let fign = 0;
function FIGURE(file, wIn, caption) {
  fign += 1;
  const buf = fs.readFileSync(path.join(FIG, file));
  const w = buf.readUInt32BE(16), h = buf.readUInt32BE(20);
  const W = Math.round(wIn * 96), H = Math.round(W * h / w);
  return [
    new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 80, after: 40 }, keepNext: true,
      children: [new ImageRun({ type: "png", data: buf, transformation: { width: W, height: H },
        altText: { title: `Figure ${fign}`, description: caption.slice(0, 120), name: file } })] }),
    new Paragraph({ alignment: AlignmentType.JUSTIFIED, spacing: { after: 140, line: 240 },
      children: [new TextRun({ text: `Figure ${fign}. `, bold: true, font: FONT, size: 18 }), ...runs(caption, { size: 18 })] }),
  ];
}
let tabn = 0;
const thin = { style: BorderStyle.SINGLE, size: 4, color: "000000" };
const none = { style: BorderStyle.NONE, size: 0, color: "FFFFFF" };
function TABLE(caption, header, rows, widths, opt = {}) {
  tabn += 1;
  const total = widths.reduce((a, b) => a + b, 0);
  const sz = opt.size || 17;
  const cell = (t, i, isHead, last, shade) => new TableCell({
    width: { size: widths[i], type: WidthType.DXA },
    margins: { top: 30, bottom: 30, left: 70, right: 70 },
    shading: shade ? { type: ShadingType.CLEAR, fill: shade, color: "auto" } : undefined,
    borders: { top: isHead ? thin : none, bottom: (isHead || last) ? thin : none, left: none, right: none },
    children: [new Paragraph({ alignment: i === 0 ? AlignmentType.LEFT : AlignmentType.CENTER,
      spacing: { before: 0, after: 0, line: 240 },
      children: String(t) === "" ? [new TextRun({ text: " ", font: FONT, size: sz })] : runs(String(t), { size: sz, bold: isHead }) })],
  });
  const trs = [new TableRow({ tableHeader: true, children: header.map((t, i) => cell(t, i, true, false)) })];
  rows.forEach((r, k) => trs.push(new TableRow({ children: r.cells.map((t, i) =>
    cell(t, i, false, k === rows.length - 1, r.shade)) })));
  return [
    new Paragraph({ alignment: AlignmentType.JUSTIFIED, keepNext: true, spacing: { before: 100, after: 60, line: 240 },
      children: [new TextRun({ text: `Table ${tabn}. `, bold: true, font: FONT, size: 18 }), ...runs(caption, { size: 18 })] }),
    new Table({ width: { size: total, type: WidthType.DXA }, columnWidths: widths, alignment: AlignmentType.CENTER, rows: trs }),
    new Paragraph({ spacing: { after: 80 }, children: [] }),
  ];
}
const bullet = (text) => new Paragraph({ numbering: { reference: "bul", level: 0 }, alignment: AlignmentType.JUSTIFIED,
  spacing: { after: 40, line: 252 }, children: runs(text) });
const REF = (i, text) => new Paragraph({ alignment: AlignmentType.LEFT, spacing: { after: 40, line: 230 },
  indent: { left: 400, hanging: 400 }, children: [new TextRun({ text: `[${i}]\t`, font: FONT, size: 18 }), ...runs(text, { size: 18 })],
  tabStops: [{ type: TabStopType.LEFT, position: 400 }] });
const PLACEHOLDER = t => new TextRun({ text: t, font: FONT, size: BASE, highlight: "yellow" });

// ---------------------------------------------------------------- numbers
const SYS = ["lorenz", "rossler"], WL = ["ensemble", "library"];
const BK = [["numba", "Numba prange"], ["pyomp", "PyOMP (OpenMP)"], ["threads", "Threads (nogil)"], ["processes", "multiprocessing"]];
const NAME = { lorenz: "Lorenz", rossler: "Rössler" };
const PHYS = 24, LOG = 48;
const S = (s, w, b, p) => T1(s, w) / get(s, w, b, p).time_best;
const ps = (s, w) => get(s, w, "pysindy").time_best;
const cases = SYS.flatMap(s => WL.map(w => [s, w]));
const allS = (p) => cases.flatMap(([s, w]) => BK.map(([b]) => S(s, w, b, p)));
const S24 = allS(PHYS), S48 = allS(LOG);
const comp = cases.map(([s, w]) => ps(s, w) / T1(s, w));
const bestT = (s, w, p) => Math.min(...BK.map(([b]) => get(s, w, b, p).time_best));
const tot24 = cases.map(([s, w]) => ps(s, w) / bestT(s, w, PHYS));
const tot48 = cases.map(([s, w]) => ps(s, w) / bestT(s, w, LOG));
const mn = a => Math.min(...a), mx = a => Math.max(...a);
const htGain = cases.flatMap(([s, w]) => BK.map(([b]) => get(s, w, b, PHYS).time_best / get(s, w, b, LOG).time_best));
// Amdahl fit from the best 24-core speed-up of the Lorenz ensemble
const Sfit = S("lorenz", "ensemble", "numba", PHYS);
const fA = (PHYS / Sfit - 1) / (PHYS - 1);
const S48A = 1 / (fA + (1 - fA) / LOG);
const acc = (s, w) => ACC ? ACC[`${s}/${w}`] : get(s, w, "serial");
const eff = (s, w, b, p) => S(s, w, b, p) / p;
const fmtE = x => { const e = Math.floor(Math.log10(x)); return `${(x / 10 ** e).toFixed(1)}×10^{${e < 0 ? "−" + (-e) : e}}`; };

// identified coefficients (paper/verify_accuracy.py, library workload N = 2e7)
function loadNpy(file) {
  const b = fs.readFileSync(file);
  const hlen = b.readUInt16LE(8);
  const header = b.slice(10, 10 + hlen).toString();
  const shape = header.match(/\((\d+), (\d+)\)/).slice(1).map(Number);
  const data = new Float64Array(b.buffer.slice(b.byteOffset + 10 + hlen, b.byteOffset + b.length));
  return { shape, at: (i, j) => data[i * shape[1] + j], nnz: () => data.filter(v => v !== 0).length };
}
const XiL = loadNpy(path.join(FIG, "Xi_lorenz.npy")), XiR = loadNpy(path.join(FIG, "Xi_rossler.npy"));
const IDX = { "1": 0, x: 1, y: 2, z: 3, xy: 5, xz: 6 };
let maxRel = 0;
const coefRows = [
  ["Lorenz", "ẋ", "x", -10, XiL, "x", 0], ["", "ẋ", "y", 10, XiL, "y", 0],
  ["", "ẏ", "x", 28, XiL, "x", 1], ["", "ẏ", "y", -1, XiL, "y", 1], ["", "ẏ", "xz", -1, XiL, "xz", 1],
  ["", "ż", "z", -8 / 3, XiL, "z", 2], ["", "ż", "xy", 1, XiL, "xy", 2],
  ["Rössler", "ẋ", "y", -1, XiR, "y", 0], ["", "ẋ", "z", -1, XiR, "z", 0],
  ["", "ẏ", "x", 1, XiR, "x", 1], ["", "ẏ", "y", 0.2, XiR, "y", 1],
  ["", "ż", "1", 0.2, XiR, "1", 2], ["", "ż", "z", -5.7, XiR, "z", 2], ["", "ż", "xz", 1, XiR, "xz", 2],
].map(([sys, eq, term, tru, Xi, key, col]) => {
  const v = Xi.at(IDX[key], col);
  const rel = Math.abs(v - tru) / Math.abs(tru) * 100; maxRel = Math.max(maxRel, rel);
  return { cells: [sys, eq, term, tru === -8 / 3 ? "−2.6667" : tru.toFixed(4).replace("-", "−"),
    v.toFixed(4).replace("-", "−"), rel.toFixed(3) + " %"] };
});

// timing table
const timeRows = [];
timeRows.push({ cells: ["PySINDy (serial)", "1", ...cases.flatMap(([s, w]) => [f2(ps(s, w)), f2(T1(s, w) / ps(s, w))])], shade: "F7F2FB" });
timeRows.push({ cells: ["Numba serial", "1", ...cases.flatMap(([s, w]) => [f2(T1(s, w)), "1.00"])], shade: "F2F2F2" });
const PS = [1, 4, 12, 24, 48];   // full set (1,2,4,8,12,16,24,48) in results_uhd/summary.md
for (const [b, lab] of BK) for (const p of PS) {
  timeRows.push({ cells: [p === 1 ? lab : "", String(p), ...cases.flatMap(([s, w]) => {
    const t = get(s, w, b, p).time_best; return [t < 10 ? f3(t) : f2(t), f2(T1(s, w) / t)];
  })], shade: p === PHYS ? "EAF4EE" : (p === LOG ? "F4F4F4" : undefined) });
}

// ---------------------------------------------------------------- content
const C = [];
C.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 0, after: 160, line: 300 },
  children: [new TextRun({ text: "Parallel Sparse Identification of Nonlinear Dynamics in Python: Task- and Data-Parallel SINDy with Numba, OpenMP, Threads and Multiprocessing for the Lorenz and Rössler Systems", font: FONT, size: 30, bold: true })] }));
C.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 30 }, children: [new TextRun({ text: "Pablo Guillen-Rondon", font: FONT, size: 24 })] }));
C.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 30 }, children: [new TextRun({ text: "University of Houston–Downtown, Houston, TX, USA", font: FONT, size: 20, italics: true })] }));
C.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 240 }, children: [new TextRun({ text: "guillenrondonp@uhd.edu", font: FONT, size: 20 })] }));

C.push(new Paragraph({ alignment: AlignmentType.JUSTIFIED, indent: { left: 500, right: 500 }, spacing: { after: 100, line: 252 },
  children: [new TextRun({ text: "Abstract. ", bold: true, font: FONT, size: 20 }), ...runs(
    `The sparse identification of nonlinear dynamics (SINDy) recovers interpretable governing equations from time-series data by sparse regression over a library of candidate functions. As data sets, candidate libraries and the number of repeated fits grow, the cost of SINDy becomes dominated by the evaluation of the library matrix and its least-squares problems. We present an open-source Python implementation of SINDy in which a single set of loop-based kernels is just-in-time compiled with Numba and executed on a shared-memory multicore node by four interchangeable back ends: Numba \`prange\`, OpenMP directives through PyOMP, Python threads that release the global interpreter lock, and \`multiprocessing\` with shared memory. The normal equations are accumulated in one cache-blocked pass over the data, with an automatic fallback to a tall-skinny QR reduction for ill-conditioned problems. Two decompositions are studied on the Lorenz and Rössler systems: an *ensemble* (task-parallel) workload of 960 independent identifications and a *library* (data-parallel) workload of one trajectory with 2×10^{7} samples and a fifth-order library of 56 candidate terms. All back ends recover the exact sparsity pattern in every identification, with coefficient errors identical to PySINDy. On a dual-socket Intel Xeon E5-2650 v4 node of the University of Houston–Downtown HPC cluster (24 cores, 48 hardware threads), the compiled serial code is ${mn(comp).toFixed(1)}–${mx(comp).toFixed(1)}× faster than PySINDy, the parallel back ends reach speed-ups of ${mn(S24).toFixed(1)}–${mx(S24).toFixed(1)} on 24 cores (parallel efficiency ${mn(S24.map(x => x / PHYS)).toFixed(2)}–${mx(S24.map(x => x / PHYS)).toFixed(2)}), and the overall time to solution is reduced by up to ${Math.round(mx(tot48))}× with respect to PySINDy. We analyse the differences between the back ends, the effect of the two sockets and of hyper-threading, and give practical recommendations.`, { size: 20 })] }));
C.push(new Paragraph({ alignment: AlignmentType.JUSTIFIED, indent: { left: 500, right: 500 }, spacing: { after: 200 },
  children: [new TextRun({ text: "Keywords: ", bold: true, font: FONT, size: 20 }),
    new TextRun({ text: "system identification; SINDy; sparse regression; parallel computing; OpenMP; Numba; multiprocessing; high-performance Python; Lorenz system; Rössler system.", font: FONT, size: 20 })] }));

// 1 Introduction
C.push(H1("1. Introduction"));
C.push(P(`Discovering the governing equations of a dynamical system directly from measurements is a central problem in data-driven science [9]. The sparse identification of nonlinear dynamics (SINDy) algorithm of Brunton, Proctor and Kutz [1] addresses it by assuming that the right-hand side of the dynamics is a sparse combination of a few candidate functions, so that a sparse regression over a library of such functions yields models that are both accurate and interpretable. SINDy has since been extended to partial differential equations [5], latent coordinates [6], implicit and rational dynamics [7], weak formulations [8] and ensemble/bootstrap variants for noisy data [4], with a recent tutorial perspective for engineering applications [11] and robust autoencoder variants [12]. The open-source PySINDy package [2, 3, 10] made these methods widely accessible.`));
C.push(P(`Practical SINDy studies rarely consist of a single fit. Model selection requires sweeps over the sparsity threshold and the library; robustness is assessed by bootstrapping [4]; and long or high-resolution experiments produce millions of samples while high-order libraries contain tens to hundreds of terms. In this regime the computation is dominated by the evaluation of the library matrix Θ(X) and by least-squares solves, and interpreter overhead and serial execution become the limiting factors.`));
C.push(P(`Python offers several mature routes to multicore execution: Numba's just-in-time (JIT) compilation with \`prange\` loops [15]; OpenMP [19] directives through PyOMP [16, 17] or pure-Python implementations such as OMP4Py [18]; ordinary threads, which run in parallel when compiled code releases the global interpreter lock (GIL) [21]; and process-based parallelism with \`multiprocessing\`. Their relative merits for equation-discovery workloads have not been systematically compared on a modern multicore node.`));
C.push(P(`This paper makes three contributions. (i) We formulate SINDy so that its expensive part is a single cache-blocked pass that accumulates the normal equations, safeguarded by a tall-skinny QR (TSQR) fallback [27] for ill-conditioned data, and implement it as one set of compiled kernels shared by all back ends. (ii) We describe task-parallel (ensemble) and data-parallel (library) decompositions and their implementation with \`prange\`, PyOMP, GIL-free threads and \`multiprocessing\`. (iii) We report a strong-scaling study from 1 to 48 hardware threads on a compute node of the University of Houston–Downtown (UHD) HPC cluster for the Lorenz [13] and Rössler [14] systems, validated against PySINDy. All code and benchmark scripts are released as open source.`));

// 2 SINDy
C.push(H1("2. Sparse identification of nonlinear dynamics"));
C.push(P(`We consider autonomous systems ẋ(t) = f(x(t)) with state x ∈ ℝ^{n}. Sampling the state at times t_{1}, …, t_{N} gives the data matrix X ∈ ℝ^{N×n} and, by numerical differentiation, Ẋ ∈ ℝ^{N×n}. SINDy postulates`));
C.push(EQ("Ẋ ≈ Θ(X) Ξ,"));
C.push(P(`where Θ(X) ∈ ℝ^{N×m} collects m candidate functions evaluated on the data and Ξ = [ξ_{1}, …, ξ_{n}] ∈ ℝ^{m×n} is a sparse coefficient matrix whose column ξ_{k} defines the k-th equation ẋ_{k} = Θ(x)ξ_{k} [1]. Θ contains all monomials of the state variables up to degree d, ordered as 1, x, y, z, x^{2}, xy, xz, y^{2}, yz, z^{2}, x^{3}, … (as in PySINDy), so that m = C(n+d, d): m = 20 for d = 3 and m = 56 for d = 5 with n = 3.`));
C.push(H2("2.1 Numerical differentiation"));
C.push(P(`Derivatives are obtained with second-order central differences, ẋ_{i} ≈ (x_{i+1} − x_{i−1})/(2Δt), and second-order one-sided formulas at the two end points, matching \`pysindy.FiniteDifference\`. The truncation error is O(Δt^{2}) and, for the noise-free data used here, is the dominant source of the coefficient errors reported in Section 5.`));
C.push(H2("2.2 Sequentially thresholded least squares"));
C.push(P(`The sparse coefficients are computed with sequentially thresholded least squares (STLSQ) [1], whose convergence was analysed in [26]. Starting from the full support, each iteration solves a ridge-regularised least-squares problem on the active columns and zeroes every coefficient whose magnitude falls below a threshold λ:`));
C.push(EQ("ξ_{k} ← argmin_{ξ} ||Θ_{S}ξ − ẋ_{k}||_{2}^{2} + α||ξ||_{2}^{2},    S ← { j : |ξ_{k,j}| ≥ λ },"));
C.push(P(`until the support S no longer changes. We use λ = 0.1 for Lorenz, λ = 0.05 for Rössler and α = 10^{−10}. Columns are scaled to unit norm for the solve, while the ridge term and the threshold are applied in the original (unscaled) units, as in PySINDy.`));
C.push(H2("2.3 Normal-equation formulation"));
C.push(P(`Every least-squares problem in STLSQ involves sub-matrices of Θ only through the Gram matrix and the projected derivatives`));
C.push(EQ("G = Θ^{⊤}Θ = Σ_{i=1}^{N} θ_{i}θ_{i}^{⊤},    R = Θ^{⊤}Ẋ = Σ_{i=1}^{N} θ_{i}ẋ_{i}^{⊤},"));
C.push(P(`where θ_{i}^{⊤} is the i-th row of Θ. The restricted problem for support S is (G_{SS} + αI)ξ_{S} = R_{S,k}, an m×m system independent of N. A single pass over the data therefore costs O(Nm^{2}) operations and O(m^{2}) memory, after which all STLSQ iterations cost O(m^{3}). The N×m matrix Θ is never stored: rows are generated in blocks of 4096 that fit in cache. Because G and R are sums over rows, the formulation is naturally parallel (Section 4). Since forming G squares the condition number of Θ [28], the code also checks the condition number of the small column-scaled Gram matrix and, above 10^{10}, recomputes the fit from the R factor of a blocked tall-skinny QR factorisation of [Θ | Ẋ] [27], which can be distributed in the same way; this happens only for nearly degenerate data.`));
// 3 test systems
C.push(H1("3. Test systems and identified models"));
C.push(P(`We use the two classical chaotic benchmarks of the SINDy literature [1]. The Lorenz system [13]`));
C.push(EQ("ẋ = σ(y − x),    ẏ = x(ρ − z) − y,    ż = xy − βz,"));
C.push(P(`with σ = 10, ρ = 28, β = 8/3, and the Rössler system [14]`));
C.push(EQ("ẋ = −y − z,    ẏ = x + ay,    ż = b + z(x − c),"));
C.push(P(`with a = b = 0.2, c = 5.7. Data are generated with a fourth-order Runge–Kutta (RK4) integrator with Δt = 0.002 (Lorenz) and Δt = 0.005 (Rössler) from random initial conditions in [−15,15]×[−20,20]×[5,40] and [−8,8]^{2}×[0,2], respectively. The data are noise-free, so that differences between back ends can only come from floating-point summation order.`));
C.push(P(`Table 1 lists the coefficients identified in the library workload, from one trajectory of N = 2×10^{7} samples with the fifth-order library (56 candidate terms per equation, 168 in total). In both systems SINDy retains exactly the seven true terms and sets the other 161 coefficients to zero; the largest relative error is ${maxRel.toFixed(2)} %. Figure 1 compares simulations of the identified and true models from the same initial condition: the Rössler trajectories are indistinguishable, and the Lorenz trajectories coincide for about seven time units before separating, as expected from the positive Lyapunov exponent of the Lorenz attractor, while both remain on the same attractor.`));
C.push(...TABLE("True and identified coefficients (library workload, N = 2×10^{7}, degree-5 library). All other 161 coefficients are exactly zero in both systems. All parallel back ends give the same values to the digits shown.",
  ["System", "Eq.", "Term", "True", "Identified", "Rel. error"], coefRows, [1300, 800, 900, 1300, 1400, 1300], { size: 17 }));
C.push(...FIGURE("fig2_attractors.png", 5.5, "Identified versus true dynamics. (a, b) Attractors of the true system (solid black) and of the SINDy model (dashed red) integrated from the same initial condition. (c, d) Time series of x(t). For Lorenz the trajectories separate after t ≈ 7 because of sensitive dependence on initial conditions, although the identified model reproduces the attractor; for Rössler they overlap for the whole window."));

// 4 parallel strategies
C.push(H1("4. Implementation and parallelization strategies"));
C.push(H2("4.1 Single-source compiled kernels"));
C.push(P(`All numerical steps (the RK4 integrator, finite differences, the library row θ_{i}, accumulation of G and R, a pivoted Gaussian-elimination solver, the conditioning check, the QR fallback and STLSQ) are written once as plain loops in a factory \`build_kernels(jit)\` that receives the decorator to use. The same source is compiled with \`numba.njit(nogil=True)\` for the serial, \`prange\`, thread and process back ends and with PyOMP's \`numba.openmp.njit\` for OpenMP, so that every back end executes the same arithmetic and differences in run time are due to the parallelization strategy alone. Inner products are written as loops rather than BLAS calls, so that no hidden library threads distort the core count.`));
C.push(H2("4.2 Two parallel decompositions"));
C.push(P(`Figure 2 summarises the pipeline and the two decompositions.`));
C.push(bullet(`**Ensemble (task parallelism).** M = 960 trajectories, each with n = 20 000 samples, are generated from different initial conditions and identified independently with a third-order library (m = 20). The work items are complete SINDy problems (integration, differentiation, library, STLSQ); workers do not communicate, and the result is M coefficient matrices. This pattern covers parameter sweeps, threshold searches, bootstrapping (ensemble-SINDy [4]) and multi-experiment studies.`));
C.push(bullet(`**Library (data parallelism).** A single trajectory with N = 2×10^{7} samples is identified with the fifth-order library (m = 56). Row blocks are distributed among p workers; worker q accumulates private partial sums G_{q}, R_{q} over its rows, the partial sums are reduced, G = Σ_{q}G_{q}, and STLSQ is solved once. Only O(pm^{2}) values are combined, independently of N.`));
C.push(...FIGURE("fig1_schematic.png", 6.3, "(a) SINDy pipeline in the normal-equation formulation; the orange steps dominate the cost. (b) Ensemble workload: whole identification problems are distributed among workers. (c) Library workload: row blocks of one long trajectory are distributed, private partial normal equations are reduced, and STLSQ is solved once."));
C.push(H2("4.3 Back ends"));
C.push(P(`**Numba \`prange\`.** A driver compiled with \`@njit(parallel=True)\` replaces \`range\` by \`prange\`, and Numba distributes the iterations over a pool of p native threads. In the library workload each iteration owns one slice of the private arrays \`Gp[t]\`, avoiding races without atomic operations:`));
C.push(...CODE([
  "@njit(parallel=True)",
  "def ensemble_prange(system, p, x0s, dt, n, expo, thr):",
  "    out = np.empty((x0s.shape[0], expo.shape[0], 3))",
  "    for t in prange(x0s.shape[0]):          # one SINDy fit per iteration",
  "        out[t] = sindy_one(system, p, x0s[t], dt, n, expo, thr)",
  "    return out",
  "",
  "@njit(parallel=True)",
  "def library_prange_fit(X, dX, expo, thr, nparts):",
  "    Gp = np.zeros((nparts, m, m)); Rp = np.zeros((nparts, m, 3))",
  "    for t in prange(nparts):                # private partial sums",
  "        gram_blocks(X, dX, expo, b0(t), b1(t), BLOCK, Gp[t], Rp[t])",
  "    G = Gp.sum(axis=0); R = Rp.sum(axis=0)  # reduction",
  "    return solve_checked(G, R, X, dX, expo, thr)   # STLSQ (+QR fallback)",
]));
C.push(P(`**OpenMP (PyOMP).** PyOMP [16, 17] lowers \`with openmp(...)\` blocks to calls into the OpenMP runtime, giving Python code the semantics of C/Fortran \`#pragma omp\` directives, including explicit scheduling, thread identifiers and private data:`));
C.push(...CODE([
  "from numba.openmp import njit, openmp_context as openmp, omp_get_thread_num",
  "@njit",
  "def library_omp_fit(X, dX, expo, thr, nthreads):",
  "    Gp = np.zeros((nthreads, m, m)); Rp = np.zeros((nthreads, m, 3))",
  "    with openmp(\"parallel num_threads(nthreads)\"):",
  "        tid = omp_get_thread_num()",
  "        with openmp(\"for schedule(static)\"):",
  "            for b in range(nblocks):",
  "                library_gram_chunk(X, dX, expo, i0(b), i1(b), Gp[tid], Rp[tid])",
  "    G = Gp.sum(axis=0); R = Rp.sum(axis=0)",
  "    return solve_checked(G, R, X, dX, expo, thr)",
]));
C.push(P(`The ensemble driver is a single \`with openmp("parallel for schedule(static)")\` loop over trajectories.`));
C.push(P(`**Python threads.** Kernels compiled with \`nogil=True\` release the GIL for their whole duration, so a \`concurrent.futures.ThreadPoolExecutor\` with p threads achieves true parallelism while the driver remains ordinary Python code. The work is split into p contiguous chunks, so the GIL is acquired only once per chunk, and threads share all arrays.`));
C.push(P(`**multiprocessing.** A \`multiprocessing.Pool\` of p worker processes, each with its own interpreter, executes the serial kernel on its chunk. In the ensemble only the initial conditions are sent and the M×m×3 coefficients returned. In the library workload X and Ẋ (0.96 GB) are copied once into \`multiprocessing.shared_memory\` blocks to which the workers attach at start-up, so each task transfers two block indices and returns an m×m and an m×3 matrix.`));

// 5 experiments
C.push(H1("5. Performance evaluation"));
C.push(H2("5.1 Experimental setup"));
C.push(P(`All measurements were taken on one compute node of the High-Performance Computing Center of the College of Sciences and Technology at UHD, a cluster of 32 compute nodes connected by Intel Omni-Path. The node has two Intel Xeon E5-2650 v4 processors (Broadwell, 2.2 GHz), each with 12 cores, for 24 physical cores and 48 hardware threads with Intel Hyper-Threading, and 256 GB of memory. The node was allocated exclusively through the Slurm scheduler. The software was Python 3.12.16 with NumPy 2.5.4, Numba 0.67.0, PyOMP and PySINDy 2.1.0 from conda-forge. Each configuration runs in a fresh interpreter in which the thread-pool size is fixed before Numba is imported and BLAS libraries are pinned to one thread. Each timing is the best of three repetitions after an untimed warm-up that triggers JIT compilation and starts the thread or process pools. The PySINDy reference uses the same data and settings (\`STLSQ(threshold=λ, alpha=1e-10)\`, \`PolynomialLibrary(degree=d)\`, \`FiniteDifference()\`) and is timed once. The worker counts p = 1, 2, 4, 8, 12, 16, 24 cover one socket (p ≤ 12) and both sockets (p = 24) with one thread per physical core, and p = 48 uses all hardware threads.`));
C.push(P(`We report the speed-up and parallel efficiency with respect to the compiled serial code,`));
C.push(EQ("S(p) = T_{serial} / T(p),    E(p) = S(p) / p,"));
C.push(P(`so that the gain due to compilation, reported separately, does not inflate the parallel speed-up.`));

C.push(H2("5.2 Accuracy"));
const aLe = acc("lorenz", "ensemble"), aRe = acc("rossler", "ensemble"), aLl = acc("lorenz", "library"), aRl = acc("rossler", "library");
C.push(P(`All back ends identify the same models. In the ensemble workloads all 960 Lorenz and all 960 Rössler identifications have the correct support, with maximum coefficient errors of ${fmtE(aLe.max_coef_error)} and ${fmtE(aRe.max_coef_error)} (medians ${fmtE(aLe.median_coef_error)} and ${fmtE(aRe.median_coef_error)}); in the library workloads the maximum errors are ${fmtE(aLl.max_coef_error)} and ${fmtE(aRl.max_coef_error)}. These values agree with those of PySINDy on the same data to at least four significant digits, confirming that the normal-equation formulation with the conditioning safeguard is as accurate as the reference implementation for these problems.`));

C.push(H2("5.3 Run time and scaling"));
C.push(P(`Table 2 lists the timings, and Figure 3 shows the speed-up and the parallel efficiency.`));
C.push(...TABLE("Wall time T [s] (best of three) and speed-up S = T_{serial}/T on the UHD compute node (2 × Xeon E5-2650 v4, 24 cores, 48 hardware threads). Ensemble: M = 960, n = 20 000, degree 3; library: N = 2×10^{7}, degree 5. For PySINDy the S column is T_{serial}/T_{PySINDy}. Rows with p = 24 (all physical cores) are shaded green, rows with p = 48 (hyper-threading) grey. Results for p = 2, 8 and 16 appear in Figure 3 and in the repository.",
  ["Back end", "p", "L-ens T", "S", "L-lib T", "S", "R-ens T", "S", "R-lib T", "S"],
  timeRows, [1850, 420, 860, 650, 860, 650, 860, 650, 860, 650], { size: 16 }));
C.push(...FIGURE("fig3_scaling.png", 6.4, "Strong scaling of the four back ends on the UHD node. Top: speed-up S(p) = T_{serial}/T(p), with ideal linear scaling dashed. Bottom: parallel efficiency E(p) = S(p)/p. The worker axis is logarithmic; the shaded region (p > 24) uses hyper-threads."));

const pL = (s, w, b, p) => f2(S(s, w, b, p));
C.push(P(`**Compilation and formulation gain.** For identical results, the compiled serial code is ${comp[0].toFixed(1)}× (Lorenz) and ${comp[2].toFixed(1)}× (Rössler) faster than PySINDy in the ensemble workload and ${comp[1].toFixed(1)}× and ${comp[3].toFixed(1)}× faster in the library workload, where PySINDy takes ${ps("lorenz", "library").toFixed(0)} s and ${ps("rossler", "library").toFixed(0)} s. In the library case the gain is partly algorithmic: PySINDy materialises the 2×10^{7}×56 matrix (about 9 GB) and solves a tall least-squares problem in every STLSQ iteration, whereas the normal-equation formulation reads the data once and iterates on a 56×56 system.`));
C.push(P(`**Scaling on physical cores.** All back ends scale well up to the 24 physical cores. At p = 12, one fully used socket, the efficiencies lie between ${mn(cases.flatMap(([s, w]) => BK.map(([b]) => eff(s, w, b, 12)))).toFixed(2)} and ${mx(cases.flatMap(([s, w]) => BK.map(([b]) => eff(s, w, b, 12)))).toFixed(2)}; extending to the second socket at p = 24 costs little further efficiency for the best back end of each workload, which shows that the cache-blocked kernels are compute-bound rather than limited by memory bandwidth or NUMA effects. On 24 cores, Numba \`prange\` reaches S = ${pL("lorenz", "ensemble", "numba", 24)} and ${pL("rossler", "ensemble", "numba", 24)} on the Lorenz and Rössler ensembles, and Python threads reach S = ${pL("lorenz", "library", "threads", 24)} and ${pL("rossler", "library", "threads", 24)} on the library workloads. Combined with compilation, the best 24-core runs are ${tot24[0].toFixed(0)}× and ${tot24[2].toFixed(0)}× faster than PySINDy for the Lorenz and Rössler ensembles, and ${tot24[1].toFixed(0)}× and ${tot24[3].toFixed(0)}× faster for the library workloads, turning a ${(ps("rossler", "library") / 60).toFixed(1)}-minute PySINDy fit into ${bestT("rossler", "library", 24).toFixed(1)} s.`));
C.push(P(`**Differences between back ends.** In the ensemble workload, the two compiled drivers (\`prange\` and PyOMP) perform best at p = 24 (S ≈ 19–20), whereas threads (S = ${pL("lorenz", "ensemble", "threads", 24)} and ${pL("rossler", "ensemble", "threads", 24)}) and \`multiprocessing\` (S = ${pL("lorenz", "ensemble", "processes", 24)} and ${pL("rossler", "ensemble", "processes", 24)}) fall behind. With a parallel run time of about 0.5 s, the fixed cost of dispatching work from Python to a thread or process pool and, for processes, of returning results through inter-process communication becomes a visible fraction of the total. In the library workload the order is reversed: threads and \`multiprocessing\` reach E(24) ≈ 0.83–0.84, while \`prange\` and PyOMP reach ${eff("lorenz", "library", "numba", 24).toFixed(2)} and ${eff("lorenz", "library", "pyomp", 24).toFixed(2)} for Lorenz. The gap is already present at p = 2 (S = ${pL("lorenz", "library", "numba", 2)} for \`prange\` against ${pL("lorenz", "library", "threads", 2)} for threads), so it is a per-thread overhead of the runtime-managed thread pools in this kernel rather than a scalability limit. A likely cause is the allocation of the per-block Θ buffer inside the parallel region; preallocating one buffer per thread is a simple remedy that we leave for a future version. The two compiled drivers, \`prange\` and PyOMP, behave almost identically throughout, which indicates that the choice between them can be made on grounds of programming style.`));
C.push(P(`**Hyper-threading.** Doubling the workers from 24 to 48 hardware threads improves the run time only by a factor ${mn(htGain).toFixed(2)}–${mx(htGain).toFixed(2)} (S(48) = ${mn(S48).toFixed(1)}–${mx(S48).toFixed(1)}), and the efficiency drops to ${mn(cases.flatMap(([s, w]) => BK.map(([b]) => eff(s, w, b, LOG)))).toFixed(2)}–${mx(cases.flatMap(([s, w]) => BK.map(([b]) => eff(s, w, b, LOG)))).toFixed(2)}. This is not explained by Amdahl's law [22]: fitting S(24) = ${f2(Sfit)} gives a serial fraction f ≈ ${fA.toFixed(4)}, which would predict S(48) ≈ ${S48A.toFixed(0)}. Instead, the two hardware threads of a core share its floating-point units, which the dense, compute-bound kernels already keep busy. The largest hyper-threading gains occur for the back ends with the most idle time at p = 24 (threads and processes in the ensemble), where the second hardware thread hides dispatch latency. For production runs on this node, 24 workers, one per physical core, are therefore the recommended setting.`));

// 6 discussion
C.push(H1("6. Discussion and practical recommendations"));
C.push(bullet(`**Reformulate before parallelizing.** Accumulating Θ^{⊤}Θ and Θ^{⊤}Ẋ in a single cache-blocked pass reduces memory from O(Nm) to O(m^{2}), makes STLSQ independent of N, exposes a simple reduction for data parallelism, and is responsible for a large part of the gain over PySINDy. The squared condition number is handled by checking the condition of the small Gram matrix and falling back to a TSQR reduction, which keeps the same parallel structure.`));
C.push(bullet(`**Choose the back end by task granularity.** Compiled drivers (\`prange\`, PyOMP) are best for many fine-grained tasks, because they dispatch work without returning to the interpreter. Python threads with \`nogil\` kernels and \`multiprocessing\` with shared memory are equally good or better for coarse tasks with little communication, and allow the parallel driver to remain ordinary Python code. \`multiprocessing\` additionally isolates memory and is the natural stepping stone to distributed execution.`));
C.push(bullet(`**Use physical cores.** On this node all back ends reach most of their attainable speed-up at 24 workers; hyper-threads add at most ${((mx(htGain) - 1) * 100).toFixed(0)} % and usually much less.`));
C.push(bullet(`**OpenMP when explicit control matters.** PyOMP exposes scheduling, data-sharing clauses and thread identifiers with familiar OpenMP semantics and performed on par with \`prange\`, which eases porting from C/Fortran. The free-threaded CPython builds enabled by PEP 703 [21] may further simplify thread-based pipelines.`));
C.push(P(`**Limitations and future work.** The experiments use noise-free data, polynomial libraries and a single shared-memory node. Noisy data require smoothing or weak formulations [8] and ensemble statistics [4], which increase the number of fits and therefore benefit directly from the ensemble strategy. Because both decompositions reduce to independent tasks or to a sum of small matrices, they extend naturally to distributed memory with MPI (a reduction of m×m Gram matrices or R̂ factors across nodes), which we plan to evaluate across the 32 nodes of the UHD cluster, together with GPU back ends.`));

// 7 conclusions
C.push(H1("7. Conclusions"));
C.push(P(`We presented a parallel implementation of SINDy in Python in which a single set of compiled kernels is executed by Numba \`prange\`, PyOMP, GIL-free threads and \`multiprocessing\`. For the Lorenz and Rössler systems all back ends recover the exact governing equations in every one of the 960 ensemble identifications and in the 2×10^{7}-sample library fits, with errors identical to PySINDy. On a 24-core compute node of the UHD HPC cluster, the normal-equation formulation and JIT compilation make the serial code ${mn(comp).toFixed(1)}–${mx(comp).toFixed(1)}× faster than PySINDy, and parallel execution adds speed-ups of up to ${mx(S24).toFixed(1)} on the physical cores, for an overall reduction of the time to solution of up to ${Math.round(mx(tot48))}×. Task-parallel ensembles and data-parallel library construction thus make SINDy studies with large data sets, rich libraries and many repeated fits practical on a single multicore node.`));

// acknowledgments
C.push(H1("Acknowledgments"));
C.push(P(`The author gratefully acknowledges the High-Performance Computing Center of the College of Sciences and Technology at the University of Houston–Downtown, operated by UHD Information Technology, for providing the computational resources used in this work. The UHD HPC cluster was established with support from a grant of the U.S. Department of Defense.`));

// code availability
C.push(H1("Code availability"));
C.push(new Paragraph({ alignment: AlignmentType.JUSTIFIED, spacing: { after: 100, line: 252 }, children: [
  ...runs("The source code (kernels, back ends, benchmark driver, Slurm job script, raw results in JSON format and the scripts that generate every figure and table of this paper) is available at "),
  new ExternalHyperlink({ link: "https://github.com/guillenrondonp/parallel-sindy", children: [new TextRun({ text: "https://github.com/guillenrondonp/parallel-sindy", font: FONT, size: BASE, color: "1F4E9E", underline: {} })] }),
  ...runs(" under an open-source license. The benchmark is reproduced with `python benchmark.py --cores 1 2 4 8 12 16 24 48 --M 960 --N 20000000`.")] }));

// references
C.push(H1("References"));
const refs = [
  "S. L. Brunton, J. L. Proctor, J. N. Kutz, “Discovering governing equations from data by sparse identification of nonlinear dynamical systems,” *Proc. Natl. Acad. Sci. USA*, 113(15):3932–3937, 2016. doi:10.1073/pnas.1517384113. arXiv:1509.03580.",
  "B. M. de Silva, K. Champion, M. Quade, J.-C. Loiseau, J. N. Kutz, S. L. Brunton, “PySINDy: A Python package for the sparse identification of nonlinear dynamical systems from data,” *J. Open Source Softw.*, 5(49):2104, 2020. doi:10.21105/joss.02104.",
  "A. A. Kaptanoglu, B. M. de Silva, U. Fasel, K. Kaheman, A. J. Goldschmidt, J. L. Callaham, C. B. Delahunt, Z. G. Nicolaou, K. Champion, J.-C. Loiseau, J. N. Kutz, S. L. Brunton, “PySINDy: A comprehensive Python package for robust sparse system identification,” *J. Open Source Softw.*, 7(69):3994, 2022. doi:10.21105/joss.03994.",
  "U. Fasel, J. N. Kutz, B. W. Brunton, S. L. Brunton, “Ensemble-SINDy: Robust sparse model discovery in the low-data, high-noise limit, with active learning and control,” *Proc. R. Soc. A*, 478:20210904, 2022. doi:10.1098/rspa.2021.0904.",
  "S. H. Rudy, S. L. Brunton, J. L. Proctor, J. N. Kutz, “Data-driven discovery of partial differential equations,” *Sci. Adv.*, 3(4):e1602614, 2017.",
  "K. Champion, B. Lusch, J. N. Kutz, S. L. Brunton, “Data-driven discovery of coordinates and governing equations,” *Proc. Natl. Acad. Sci. USA*, 116(45):22445–22451, 2019.",
  "K. Kaheman, J. N. Kutz, S. L. Brunton, “SINDy-PI: A robust algorithm for parallel implicit sparse identification of nonlinear dynamics,” *Proc. R. Soc. A*, 476:20200279, 2020.",
  "D. A. Messenger, D. M. Bortz, “Weak SINDy: Galerkin-based data-driven model selection,” *Multiscale Model. Simul.*, 19(3):1474–1497, 2021.",
  "S. L. Brunton, J. N. Kutz, *Data-Driven Science and Engineering: Machine Learning, Dynamical Systems, and Control*, 2nd ed., Cambridge University Press, 2022.",
  "J. Stevens-Haas, *Open-Source Dynamical Systems Research, with a Side of (Francis) Bacon*, Ph.D. thesis, University of Washington, 2025.",
  "Y. C. Li, A. Larrañaga, S. L. Brunton, U. Fasel, “An introduction to sparse identification of nonlinear dynamics for engineering applications,” arXiv:2607.15077, 2026.",
  "K. Ding, “A robust SINDy autoencoder for noisy dynamical system identification,” arXiv:2604.04829, 2026.",
  "E. N. Lorenz, “Deterministic nonperiodic flow,” *J. Atmos. Sci.*, 20(2):130–141, 1963.",
  "O. E. Rössler, “An equation for continuous chaos,” *Phys. Lett. A*, 57(5):397–398, 1976.",
  "S. K. Lam, A. Pitrou, S. Seibert, “Numba: A LLVM-based Python JIT compiler,” in *Proc. 2nd Workshop on the LLVM Compiler Infrastructure in HPC*, ACM, 2015. doi:10.1145/2833157.2833162.",
  "T. Anderson, T. Mattson, “Multithreaded parallel Python through OpenMP support in Numba,” in *Proc. 20th Python in Science Conf. (SciPy 2021)*, pp. 140–147, 2021. doi:10.25080/majora-1b6fd038-012.",
  "G. Georgakoudis, T. A. Anderson, S. Archibald, B. de Supinski, T. G. Mattson, “PyOMP: Parallel programming for CPUs and GPUs with OpenMP and Python,” *SC24 Workshop on High Performance Python for Science at Scale (HPPSS)*, 2024.",
  "C. A. Piñeiro Pomar, J. C. Pichel Campos, “OMP4Py: A pure Python implementation of OpenMP,” *Future Gener. Comput. Syst.*, 175:108035, 2025. doi:10.1016/j.future.2025.108035.",
  "L. Dagum, R. Menon, “OpenMP: An industry standard API for shared-memory programming,” *IEEE Comput. Sci. Eng.*, 5(1):46–55, 1998.",
  "C. R. Harris et al., “Array programming with NumPy,” *Nature*, 585:357–362, 2020.",
  "S. Gross, “PEP 703 – Making the Global Interpreter Lock optional in CPython,” Python Enhancement Proposals, 2023.",
  "G. M. Amdahl, “Validity of the single processor approach to achieving large scale computing capabilities,” in *AFIPS Conf. Proc.*, 30:483–485, 1967.",
  "J. L. Gustafson, “Reevaluating Amdahl's law,” *Commun. ACM*, 31(5):532–533, 1988.",
  "P. Virtanen et al., “SciPy 1.0: Fundamental algorithms for scientific computing in Python,” *Nat. Methods*, 17:261–272, 2020.",
  "J. D. Hunter, “Matplotlib: A 2D graphics environment,” *Comput. Sci. Eng.*, 9(3):90–95, 2007.",
  "L. Zhang, H. Schaeffer, “On the convergence of the SINDy algorithm,” *Multiscale Model. Simul.*, 17(3):948–972, 2019.",
  "J. Demmel, L. Grigori, M. Hoemmen, J. Langou, “Communication-optimal parallel and sequential QR and LU factorizations,” *SIAM J. Sci. Comput.*, 34(1):A206–A239, 2012.",
  "G. H. Golub, C. F. Van Loan, *Matrix Computations*, 4th ed., Johns Hopkins University Press, 2013.",
];
refs.forEach((r, i) => C.push(REF(i + 1, r)));

// ---------------------------------------------------------------- document
const doc = new Document({
  creator: "Pablo Guillen-Rondon",
  title: "Parallel Sparse Identification of Nonlinear Dynamics in Python",
  styles: {
    default: { document: { run: { font: FONT, size: BASE } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { font: FONT, size: 24, bold: true }, paragraph: { spacing: { before: 200, after: 90 }, outlineLevel: 0, keepNext: true } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { font: FONT, size: 21, bold: true, italics: true }, paragraph: { spacing: { before: 130, after: 70 }, outlineLevel: 1, keepNext: true } },
    ],
  },
  numbering: { config: [{ reference: "bul", levels: [{ level: 0, format: LevelFormat.BULLET, text: "•", alignment: AlignmentType.LEFT,
    style: { paragraph: { indent: { left: 360, hanging: 240 } } } }] }] },
  sections: [{
    properties: { page: { size: { width: 12240, height: 15840 }, margin: { top: 1300, bottom: 1300, left: 1440, right: 1440 } } },
    footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER,
      children: [new TextRun({ children: [PageNumber.CURRENT], font: FONT, size: 18 })] })] }) },
    children: C,
  }],
});
const OUTF = path.join(__dirname, "Parallel_SINDy_Guillen-Rondon_2026.docx");
Packer.toBuffer(doc).then(b => { fs.writeFileSync(OUTF, b); console.log("wrote", OUTF); });
