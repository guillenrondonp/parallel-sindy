"""
verify_accuracy.py -- accuracy of the FINAL solver at the cluster problem sizes
(ensemble M=960, n=20000, degree 3; library N=2e7, degree 5). The data are
deterministic (fixed seeds), so this is machine-independent. Also saves the
identified library-workload coefficients used in Table 1.

    python paper/verify_accuracy.py  ->  results_uhd/accuracy_final_code.json
"""
import json, os, sys, time
os.environ.setdefault("NUMBA_NUM_THREADS", str(os.cpu_count()))
import numpy as np
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
from sindy_core import *
import backends_numba as B
import numba
numba.set_num_threads(os.cpu_count())

out = {}
for s in ("lorenz", "rossler"):
    sid, p, dt, thr = SYSTEMS[s], DEFAULT_PARAMS[s], DEFAULT_DT[s], DEFAULT_THRESHOLD[s]
    e3 = exponent_table(3, 3); t3 = true_coefficients(s, e3)
    Xi = B.ensemble_prange(sid, p, initial_conditions(s, 960, seed=1), dt, 20000, e3, thr)
    err = np.abs(Xi - t3[None]).max(axis=(1, 2))
    sup = np.all((Xi != 0) == (t3[None] != 0), axis=(1, 2))
    out[f"{s}/ensemble"] = dict(max_coef_error=float(err.max()), median_coef_error=float(np.median(err)),
                                correct_support_fraction=float(sup.mean()), n_fail=int((~sup).sum()))
    e5 = exponent_table(3, 5); t5 = true_coefficients(s, e5)
    X = B.K["integrate_rk4"](sid, p, initial_conditions(s, 1, seed=7)[0], dt, 20_000_000)
    dX = B.K["central_diff"](X, dt)
    Xl = B.library_prange_fit(X, dX, e5, thr, os.cpu_count())
    np.save(os.path.join(ROOT, "paper", "figures", f"Xi_{s}.npy"), Xl)
    out[f"{s}/library"] = dict(max_coef_error=float(np.abs(Xl - t5).max()),
                               correct_support_fraction=float(np.all((Xl != 0) == (t5 != 0))),
                               nnz=int(np.count_nonzero(Xl)))
    print(s, out[f"{s}/ensemble"], out[f"{s}/library"], flush=True)
os.makedirs(os.path.join(ROOT, "results_uhd"), exist_ok=True)
json.dump(out, open(os.path.join(ROOT, "results_uhd", "accuracy_final_code.json"), "w"), indent=1)
