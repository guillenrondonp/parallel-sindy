"""
benchmark.py
============
Strong-scaling benchmark of parallel SINDy on the Lorenz and Rossler systems.

For every system x workload x backend x core count it launches
run_backend.py in a fresh process, collects the JSON, and writes

    results/results.json        raw timings + accuracy
    results/summary.md          tables: time, speed-up S(p), efficiency E(p)
    results/speedup.png         S(p) = T_serial / T_backend(p)  with ideal line
    results/efficiency.png      E(p) = S(p) / p
    results/time.png            wall-clock time (log scale), PySINDy for reference

Usage
-----
    python benchmark.py                          # cores = 1,2,4,... up to all
    python benchmark.py --cores 1 2 4 8 16       # explicit list
    python benchmark.py --quick                  # small problem, fast check
    python benchmark.py --backends numba pyomp   # subset
"""
import argparse
import json
import os
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
PARALLEL = ["numba", "pyomp", "threads", "processes"]
LABEL = {"serial": "Numba serial", "numba": "Numba prange", "pyomp": "PyOMP (OpenMP)",
         "threads": "Python threads (nogil)", "processes": "multiprocessing",
         "pysindy": "PySINDy (reference)"}
COLOR = {"numba": "#2a6fdb", "pyomp": "#d1495b", "threads": "#00a37a",
         "processes": "#e08e0b", "serial": "#555555", "pysindy": "#8c6bb1"}
MARK = {"numba": "o", "pyomp": "s", "threads": "^", "processes": "D"}


def default_cores():
    n = os.cpu_count() or 1
    c, out = 1, []
    while c < n:
        out.append(c); c *= 2
    out.append(n)
    return out


def support_str(r):
    """Exact count of correctly identified models, e.g. '959/960 !!'."""
    total = r.get("M", 1)
    ok = int(round(r["correct_support_fraction"] * total))
    return f"{ok}/{total}" + ("" if ok == total else "  !! WRONG MODELS")


def check_import(code):
    out = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True)
    if out.returncode == 0:
        return True, out.stdout.strip()
    lines = out.stderr.strip().splitlines()
    return False, lines[-1] if lines else "unknown error"


def run_case(system, workload, backend, cores, repeats, sizes):
    cmd = [sys.executable, str(HERE / "run_backend.py"), "--system", system,
           "--workload", workload, "--backend", backend, "--cores", str(cores),
           "--repeats", str(repeats)] + sizes
    out = subprocess.run(cmd, capture_output=True, text=True, cwd=HERE)
    if out.returncode != 0:
        print(f"  !! {system}/{workload}/{backend}/{cores} failed:\n{out.stderr[-800:]}")
        return None
    return json.loads(out.stdout.strip().splitlines()[-1])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cores", type=int, nargs="+", default=default_cores())
    ap.add_argument("--systems", nargs="+", default=["lorenz", "rossler"])
    ap.add_argument("--workloads", nargs="+", default=["ensemble", "library"])
    ap.add_argument("--backends", nargs="+", default=PARALLEL)
    ap.add_argument("--repeats", type=int, default=3)
    ap.add_argument("--no-pysindy", action="store_true")
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--M", type=int, default=96)
    ap.add_argument("--n", type=int, default=20000)
    ap.add_argument("--N", type=int, default=2_000_000)
    ap.add_argument("--out", default=str(HERE / "results"))
    a = ap.parse_args()
    if a.quick:
        a.M, a.n, a.N, a.repeats = 16, 10000, 200_000, 2

    sizes = ["--M", str(a.M), "--n", str(a.n), "--N", str(a.N)]
    outdir = Path(a.out); outdir.mkdir(parents=True, exist_ok=True)

    # ---- preflight: check dependencies once, in separate interpreters ----
    ok, msg = check_import("import numpy, numba; print(numpy.__version__, numba.__version__)")
    if not ok:
        sys.exit(f"Numba cannot be imported in this environment:\n  {msg}\n\n"
                 "Fix (recommended, leaves your base env untouched):\n"
                 "  conda create -n sindy python=3.13 -y && conda activate sindy\n"
                 "  pip install numpy numba pysindy matplotlib pyomp\n"
                 "or, in the current env:  pip install -U numba")
    print(f"numpy / numba: {msg}")
    if "pyomp" in a.backends:
        ok, msg = check_import("from numba.openmp import njit, openmp_context")
        if not ok:
            print(f"PyOMP unavailable ({msg}) -> skipping the pyomp backend")
            a.backends = [b for b in a.backends if b != "pyomp"]
    if not a.no_pysindy:
        ok, msg = check_import("import pysindy")
        if not ok:
            print(f"PySINDy unavailable ({msg}) -> skipping the reference run "
                  "(pip install pysindy)")
            a.no_pysindy = True
    ncpu = os.cpu_count() or 1
    too_many = [c for c in a.cores if c > ncpu]
    if too_many:
        print(f"skipping {too_many}: this machine has only {ncpu} logical CPUs "
              "(more workers than CPUs would only time-share them)")
        a.cores = [c for c in a.cores if c <= ncpu]
    print(f"cores tested: {a.cores}   (machine has {ncpu} logical CPUs)")

    results = []
    for system in a.systems:
        for wl in a.workloads:
            print(f"\n== {system} / {wl} ==")
            jobs = [("serial", 1)] + [(b, p) for b in a.backends for p in a.cores]
            if not a.no_pysindy:
                jobs.append(("pysindy", 1))
            for b, p in jobs:
                r = run_case(system, wl, b, p, 1 if b == "pysindy" else a.repeats, sizes)
                if r:
                    results.append(r)
                    print(f"  {LABEL[b]:24s} p={p:<3d} t={r['time_best']:9.4f} s   "
                          f"max|Xi-Xi_true|={r['max_coef_error']:.2e}  "
                          f"correct models={support_str(r)}")

    if not results:
        sys.exit("\nNo case succeeded; see the errors above.")
    (outdir / "results.json").write_text(json.dumps(results, indent=1))
    write_summary(results, outdir, a)
    make_plots(results, outdir)
    print(f"\nresults written to {outdir}")


def _get(results, s, w, b, p=None):
    for r in results:
        if r["system"] == s and r["workload"] == w and r["backend"] == b and (p is None or r["cores"] == p):
            return r
    return None


def write_summary(results, outdir, a):
    lines = [f"# Parallel SINDy benchmark\n",
             f"Machine: {os.cpu_count()} logical CPUs. Times are the best of {a.repeats} runs "
             f"after a JIT/pool warm-up.\n",
             "S(p) = T(Numba serial) / T(backend, p cores); E(p) = S(p)/p.\n"]
    for s in sorted({r["system"] for r in results}):
        for w in sorted({r["workload"] for r in results if r["system"] == s}):
            ser = _get(results, s, w, "serial")
            if not ser:
                continue
            T1 = ser["time_best"]
            desc = (f"M={ser['M']} trajectories x n={ser['n']} samples, degree {ser['degree']}"
                    if w == "ensemble" else f"N={ser['N']} samples, degree {ser['degree']} "
                    f"({ser['terms']} candidate terms)")
            lines.append(f"\n## {s.capitalize()} - {w} ({desc})\n")
            lines.append(f"Numba serial: {T1:.4f} s")
            ps = _get(results, s, w, "pysindy")
            if ps:
                lines.append(f" | PySINDy serial: {ps['time_best']:.4f} s "
                             f"(compiled serial is {ps['time_best'] / T1:.1f}x faster)")
            lines.append("\n\n| backend | cores | time [s] | speed-up S | efficiency E | max coef. error | correct models |")
            lines.append("|---|---:|---:|---:|---:|---:|---:|")
            for b in PARALLEL:
                for r in sorted([r for r in results if r["system"] == s and r["workload"] == w
                                 and r["backend"] == b], key=lambda r: r["cores"]):
                    S = T1 / r["time_best"]
                    lines.append(f"| {LABEL[b]} | {r['cores']} | {r['time_best']:.4f} | "
                                 f"{S:.2f} | {S / r['cores']:.2f} | {r['max_coef_error']:.1e} | {support_str(r)} |")
    (outdir / "summary.md").write_text("\n".join(lines) + "\n")


def make_plots(results, outdir):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    systems = sorted({r["system"] for r in results})
    workloads = [w for w in ("ensemble", "library") if any(r["workload"] == w for r in results)]

    for kind in ("speedup", "efficiency", "time"):
        fig, axes = plt.subplots(len(workloads), len(systems), squeeze=False,
                                 figsize=(5.2 * len(systems), 4.0 * len(workloads)))
        for i, w in enumerate(workloads):
            for j, s in enumerate(systems):
                ax = axes[i, j]
                ser = _get(results, s, w, "serial")
                if not ser:
                    continue
                T1 = ser["time_best"]
                allp = sorted({r["cores"] for r in results if r["backend"] in PARALLEL})
                for b in PARALLEL:
                    rs = sorted([r for r in results if r["system"] == s and r["workload"] == w
                                 and r["backend"] == b], key=lambda r: r["cores"])
                    if not rs:
                        continue
                    p = [r["cores"] for r in rs]
                    t = [r["time_best"] for r in rs]
                    y = {"speedup": [T1 / x for x in t],
                         "efficiency": [T1 / x / q for x, q in zip(t, p)],
                         "time": t}[kind]
                    ax.plot(p, y, marker=MARK[b], color=COLOR[b], lw=2, ms=6, label=LABEL[b])
                if kind == "speedup":
                    ax.plot(allp, allp, "k--", lw=1, label="ideal S = p")
                elif kind == "efficiency":
                    ax.axhline(1.0, color="k", ls="--", lw=1, label="ideal E = 1")
                    ax.set_ylim(0, 1.15)
                else:
                    ax.axhline(T1, color=COLOR["serial"], ls=":", lw=1.5, label=LABEL["serial"])
                    ps = _get(results, s, w, "pysindy")
                    if ps:
                        ax.axhline(ps["time_best"], color=COLOR["pysindy"], ls="-.", lw=1.5,
                                   label=LABEL["pysindy"])
                    ax.set_yscale("log")
                ax.set_xticks(allp)
                ax.set_xlabel("cores p")
                ax.set_ylabel({"speedup": "speed-up S(p)", "efficiency": "efficiency E(p)",
                               "time": "wall time [s]"}[kind])
                ax.set_title(f"{s.capitalize()} - {w}")
                ax.grid(alpha=0.3)
                if i == 0 and j == 0:
                    ax.legend(fontsize=8)
        fig.tight_layout()
        fig.savefig(outdir / f"{kind}.png", dpi=140)
        plt.close(fig)


if __name__ == "__main__":
    main()
